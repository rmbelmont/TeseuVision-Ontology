package br.unirio.teseuvision;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;
import org.semanticweb.owlapi.search.EntitySearcher;

import java.io.File;
import java.util.*;

/**
 * TeseuVisionConsultas - Sistema de Consultas para TeseuVision-Ontology
 *
 * Implementa as 7 Questões de Competência da ontologia do
 * Paradoxo do Navio de Teseu e da Crise de Identidade do Visão
 * em "WandaVision" (2021).
 *
 * Baseado em:
 *  - Paradoxo do Navio de Teseu (Plutarco, Hobbes)
 *  - WandaVision (Marvel Studios, 2021)
 *  - Teorias da Identidade Pessoal (Locke, Parfit)
 *  - Relatividade Sortal (Wiggins, Strawson)
 */
public class TeseuVisionConsultas {

    private static final String NS = "http://www.unirio.br/teseuvision/ontology#";
    private static final String SEPARATOR = "=".repeat(90);

    // ============================================================
    // CAMINHOS  (CORRIGIDO: TeseuVision-Ontology com hífen)
    // ============================================================
    private static final String ONTOLOGY_PATH =
        "D:/EclipseLunar/workspace/TeseuVision-Ontology/ontology/teseuvision-ontology.rdf";

    private static final String PDF_OUTPUT_PATH =
        "D:/EclipseLunar/workspace/TeseuVision-Ontology/ontology/teseuvision-ieee-2026.pdf";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";
    private static final String ANSI_BOLD = "\u001B[1m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private OWLReasoner reasoner;
    private Scanner scanner;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propTemParte;
    private OWLObjectProperty propEParteDe;
    private OWLObjectProperty propEConstituidoPor;
    private OWLObjectProperty propConstitui;
    private OWLObjectProperty propSubstitui;
    private OWLObjectProperty propTemMemoria;
    private OWLObjectProperty propTemConsciencia;
    private OWLObjectProperty propTemCorpo;
    private OWLObjectProperty propMesmoNavioQue;
    private OWLObjectProperty propTemMesmaMateriaQue;
    private OWLObjectProperty propMesmaPessoaPorMemoria;
    private OWLObjectProperty propMesmaPessoaPorCorpo;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphHasYear;
    private OWLDataProperty dphHasCanonicalStatus;
    private OWLDataProperty dphHasCriterioAdotado;
    private OWLDataProperty dphHasFonte;

    public TeseuVisionConsultas() {
        this.scanner = new Scanner(System.in);
        try {
            loadOntology();
            initializeProperties();

            StructuralReasonerFactory reasonerFactory = new StructuralReasonerFactory();
            this.reasoner = reasonerFactory.createReasoner(ontology);

            System.out.println(ANSI_GREEN + "✅ Ontologia carregada com sucesso!" + ANSI_RESET);
            System.out.println("  Arquivo: " + ONTOLOGY_PATH);
            System.out.println("  Axiomas: " + ontology.getAxiomCount());
            System.out.println("  Classes: " + ontology.getClassesInSignature().size());
            System.out.println("  Indivíduos: " + ontology.getIndividualsInSignature().size());
            System.out.println();

            showMenu();

        } catch (Exception e) {
            System.err.println(ANSI_RED + "❌ Erro: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
        }
    }

    private void loadOntology() throws Exception {
        this.manager = OWLManager.createOWLOntologyManager();
        this.factory = manager.getOWLDataFactory();

        File ontologyFile = new File(ONTOLOGY_PATH);
        if (!ontologyFile.exists()) {
            throw new Exception("Arquivo não encontrado: " + ONTOLOGY_PATH);
        }

        this.ontology = manager.loadOntologyFromOntologyDocument(ontologyFile);
        System.out.println(ANSI_GREEN + "📄 Ontologia carregada: " + ontologyFile.getName() + ANSI_RESET);
    }

    private void initializeProperties() {
        // Propriedades de objeto
        propTemParte = getObjectProperty("temParte");
        propEParteDe = getObjectProperty("eParteDe");
        propEConstituidoPor = getObjectProperty("eConstituidoPor");
        propConstitui = getObjectProperty("constitui");
        propSubstitui = getObjectProperty("substitui");
        propTemMemoria = getObjectProperty("temMemoria");
        propTemConsciencia = getObjectProperty("temConsciencia");
        propTemCorpo = getObjectProperty("temCorpo");
        propMesmoNavioQue = getObjectProperty("mesmoNavioQue");
        propTemMesmaMateriaQue = getObjectProperty("temMesmaMateriaQue");
        propMesmaPessoaPorMemoria = getObjectProperty("mesmaPessoaPorMemoria");
        propMesmaPessoaPorCorpo = getObjectProperty("mesmaPessoaPorCorpo");

        // Propriedades de dados
        dphHasName = getDataProperty("hasName");
        dphHasDescription = getDataProperty("hasDescription");
        dphHasYear = getDataProperty("hasYear");
        dphHasCanonicalStatus = getDataProperty("hasCanonicalStatus");
        dphHasCriterioAdotado = getDataProperty("hasCriterioAdotado");
        dphHasFonte = getDataProperty("hasFonte");
    }

    private OWLObjectProperty getObjectProperty(String name) {
        return factory.getOWLObjectProperty(IRI.create(NS + name));
    }

    private OWLDataProperty getDataProperty(String name) {
        return factory.getOWLDataProperty(IRI.create(NS + name));
    }

    // ============================================================
    // MÉTODOS AUXILIARES DE CONSULTA
    // ============================================================

    private Set<OWLNamedIndividual> getIndividualsByPrefix(String prefix) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (ontology == null) return result;

        try {
            Set<OWLNamedIndividual> allInds = ontology.getIndividualsInSignature();
            for (OWLNamedIndividual ind : allInds) {
                String iri = ind.getIRI().getShortForm();
                if (iri.startsWith(prefix)) {
                    result.add(ind);
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    private Set<OWLNamedIndividual> getShips() {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getIndividualsByPrefix("Navio"));
        return result;
    }

    private Set<OWLNamedIndividual> getPlanks() {
        return getIndividualsByPrefix("Tabua");
    }

    private Set<OWLNamedIndividual> getAggregates() {
        return getIndividualsByPrefix("Agregado");
    }

    private Set<OWLNamedIndividual> getVisions() {
        Set<OWLNamedIndividual> result = new HashSet<>();
        result.addAll(getIndividualsByPrefix("Visao"));
        return result;
    }

    private Set<OWLNamedIndividual> getBodies() {
        return getIndividualsByPrefix("Corpo");
    }

    private Set<OWLNamedIndividual> getMemories() {
        return getIndividualsByPrefix("Memoria");
    }

    private Set<OWLNamedIndividual> getConsciousness() {
        return getIndividualsByPrefix("Consciencia");
    }

    private String getDataValue(OWLNamedIndividual individual, OWLDataProperty prop) {
        if (individual == null || prop == null) return null;
        try {
            Optional<OWLLiteral> literal = EntitySearcher
                .getDataPropertyValues(individual, prop, ontology).findFirst();
            return literal.map(OWLLiteral::getLiteral).orElse(null);
        } catch (Exception e) { return null; }
    }

    private String getName(OWLNamedIndividual individual) {
        if (individual == null) return "N/A";
        String name = getDataValue(individual, dphHasName);
        if (name != null && !name.isEmpty()) return name;
        String iri = individual.getIRI().getShortForm();
        return iri.replace("_", " ");
    }

    private Set<OWLNamedIndividual> getRelated(OWLNamedIndividual individual, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || prop == null || ontology == null) return result;

        try {
            Set<OWLObjectPropertyAssertionAxiom> axioms =
                ontology.getObjectPropertyAssertionAxioms(individual);
            for (OWLObjectPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop) && axiom.getSubject().equals(individual)) {
                    OWLIndividual object = axiom.getObject();
                    if (object instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) object);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getRelatedInverse(OWLNamedIndividual object, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (object == null || prop == null || ontology == null) return result;

        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getAxioms(AxiomType.OBJECT_PROPERTY_ASSERTION)) {
                if (axiom.getProperty().equals(prop) && axiom.getObject().equals(object)) {
                    OWLIndividual subject = axiom.getSubject();
                    if (subject instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) subject);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    /**
     * Retorna os pares (x, y) tais que x é o mesmo que y via owl:sameAs.
     *
     * OWLSameIndividualAxiom não possui o método contains(...).
     * É preciso iterar sobre getIndividuals() para verificar pertencimento.
     */
    private Set<OWLNamedIndividual> getSameIndividuals(OWLNamedIndividual individual) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || ontology == null) return result;

        try {
            for (OWLSameIndividualAxiom axiom : ontology.getAxioms(AxiomType.SAME_INDIVIDUAL)) {
                Set<OWLIndividual> individuals = axiom.getIndividuals();
                if (individuals.contains(individual)) {
                    for (OWLIndividual ind : individuals) {
                        if (ind instanceof OWLNamedIndividual && !ind.equals(individual)) {
                            result.add((OWLNamedIndividual) ind);
                        }
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    /**
     * Retorna os indivíduos declarados diferentes via owl:differentFrom.
     *
     * OWLDifferentIndividualsAxiom não possui o método contains(...).
     * É preciso iterar sobre getIndividuals() para verificar pertencimento.
     */
    private Set<OWLNamedIndividual> getDifferentIndividuals(OWLNamedIndividual individual) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || ontology == null) return result;

        try {
            for (OWLDifferentIndividualsAxiom axiom : ontology.getAxioms(AxiomType.DIFFERENT_INDIVIDUALS)) {
                Set<OWLIndividual> individuals = axiom.getIndividuals();
                if (individuals.contains(individual)) {
                    for (OWLIndividual ind : individuals) {
                        if (ind instanceof OWLNamedIndividual && !ind.equals(individual)) {
                            result.add((OWLNamedIndividual) ind);
                        }
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    // ============================================================
    // EXIBIÇÃO DAS QUESTÕES DE COMPETÊNCIA
    // ============================================================

    private void displayQC1() {
        printHeader("QC1 - Quais navios participam do paradoxo?");

        Set<OWLNamedIndividual> ships = getShips();

        System.out.println("\n  ⚓ Total de Navios: " + ships.size() + "\n");
        System.out.println("  " + "-".repeat(80));

        int count = 0;
        for (OWLNamedIndividual ship : ships) {
            count++;
            String nome = getName(ship);
            String desc = getDataValue(ship, dphHasDescription);
            String fonte = getDataValue(ship, dphHasFonte);
            String criterio = getDataValue(ship, dphHasCriterioAdotado);
            String ano = getDataValue(ship, dphHasYear);

            System.out.printf("  %d. %s%n", count, nome);
            if (desc != null) System.out.printf("     Descrição: %s%n", desc);
            if (ano != null) System.out.printf("     Ano: %s%n", ano);
            if (criterio != null) System.out.printf("     Critério adotado: %s%n", criterio);
            if (fonte != null) System.out.printf("     Fonte: %s%n", fonte);

            Set<OWLNamedIndividual> agregados = getRelated(ship, propEConstituidoPor);
            if (!agregados.isEmpty()) {
                System.out.print("     Constituído por: ");
                for (OWLNamedIndividual ag : agregados) {
                    System.out.print("[" + getName(ag) + "] ");
                }
                System.out.println();
            }

            System.out.println("  " + "-".repeat(80));
        }

        printFooter();
    }

    private void displayQC2() {
        printHeader("QC2 - Qual navio é o mesmo NAVIO que o original?");

        OWLNamedIndividual navioOriginal = factory.getOWLNamedIndividual(IRI.create(NS + "NavioOriginal"));

        System.out.println("\n  ⚓ Identidade sob o sortal NAVIO (mesmoNavioQue):\n");
        System.out.println("  " + "-".repeat(80));

        Set<OWLNamedIndividual> mesmos = getRelated(navioOriginal, propMesmoNavioQue);
        mesmos.addAll(getRelatedInverse(navioOriginal, propMesmoNavioQue));

        System.out.printf("%n  Navio original: %s%n", getName(navioOriginal));

        System.out.println("\n  Pares afirmados (mesmoNavioQue):");
        if (mesmos.isEmpty()) {
            System.out.println("     (nenhum)");
        } else {
            for (OWLNamedIndividual n : mesmos) {
                System.out.printf("     • %s  ≡  %s%n",
                    getName(navioOriginal), getName(n));
            }
        }

        System.out.println("\n  📌 Interpretação:");
        System.out.println("     Por continuidade formal, funcional e causal,");
        System.out.println("     o Navio A (peças substituídas continuamente) é o");
        System.out.println("     mesmo NAVIO que o original.");
        System.out.println("     O Navio B (remontado com peças originais) NÃO é");
        System.out.println("     o mesmo navio sob este critério.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC3() {
        printHeader("QC3 - Qual navio tem a mesma MATÉRIA que o original?");

        OWLNamedIndividual navioOriginal = factory.getOWLNamedIndividual(IRI.create(NS + "NavioOriginal"));

        System.out.println("\n  🪵 Identidade sob o sortal MATÉRIA (temMesmaMateriaQue):\n");
        System.out.println("  " + "-".repeat(80));

        Set<OWLNamedIndividual> mesmaMateria = getRelated(navioOriginal, propTemMesmaMateriaQue);
        mesmaMateria.addAll(getRelatedInverse(navioOriginal, propTemMesmaMateriaQue));

        System.out.printf("%n  Navio original: %s%n", getName(navioOriginal));

        System.out.println("\n  Pares afirmados (temMesmaMateriaQue):");
        if (mesmaMateria.isEmpty()) {
            System.out.println("     (nenhum)");
        } else {
            for (OWLNamedIndividual n : mesmaMateria) {
                System.out.printf("     • %s  ≡  %s%n",
                    getName(navioOriginal), getName(n));

                Set<OWLNamedIndividual> agOrig = getRelated(navioOriginal, propEConstituidoPor);
                Set<OWLNamedIndividual> agOutro = getRelated(n, propEConstituidoPor);
                Set<OWLNamedIndividual> intersec = new HashSet<>(agOrig);
                intersec.retainAll(agOutro);
                if (!intersec.isEmpty()) {
                    System.out.print("       Agregado compartilhado: ");
                    for (OWLNamedIndividual ag : intersec) {
                        System.out.print("[" + getName(ag) + "] ");
                    }
                    System.out.println();
                }
            }
        }

        System.out.println("\n  📌 Interpretação:");
        System.out.println("     Por compartilhar o mesmo agregado material");
        System.out.println("     (as tábuas originais), o Navio B tem a mesma");
        System.out.println("     MATÉRIA que o original. O Navio A NÃO tem a");
        System.out.println("     mesma matéria, embora seja o mesmo navio.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC4() {
        printHeader("QC4 - Quais são as dimensões constitutivas de cada Visão?");

        Set<OWLNamedIndividual> visoes = getVisions();

        System.out.println("\n  🧠 Dimensões constitutivas dos Visões:\n");
        System.out.println("  " + "-".repeat(80));

        for (OWLNamedIndividual visao : visoes) {
            String nome = getName(visao);
            String desc = getDataValue(visao, dphHasDescription);
            String criterio = getDataValue(visao, dphHasCriterioAdotado);

            System.out.printf("%n  👤 %s%n", nome);
            if (desc != null) System.out.printf("     Descrição: %s%n", desc);
            if (criterio != null) System.out.printf("     Critério adotado: %s%n", criterio);

            Set<OWLNamedIndividual> corpos = getRelated(visao, propTemCorpo);
            System.out.print("     Corpo:        ");
            if (corpos.isEmpty()) {
                System.out.println("(ausente)");
            } else {
                for (OWLNamedIndividual c : corpos) System.out.print("[" + getName(c) + "] ");
                System.out.println();
            }

            Set<OWLNamedIndividual> memorias = getRelated(visao, propTemMemoria);
            System.out.print("     Memória:      ");
            if (memorias.isEmpty()) {
                System.out.println("(ausente)");
            } else {
                for (OWLNamedIndividual m : memorias) System.out.print("[" + getName(m) + "] ");
                System.out.println();
            }

            Set<OWLNamedIndividual> consciencias = getRelated(visao, propTemConsciencia);
            System.out.print("     Consciência:  ");
            if (consciencias.isEmpty()) {
                System.out.println("(ausente)");
            } else {
                for (OWLNamedIndividual c : consciencias) System.out.print("[" + getName(c) + "] ");
                System.out.println();
            }

            System.out.println("  " + "-".repeat(80));
        }

        System.out.println("\n  📌 Resumo:");
        System.out.println("     VisaoOriginal -> corpo=Original, memoria=Original, consc=Original");
        System.out.println("     VisaoHex      -> corpo=Ausente,  memoria=Original, consc=Hex");
        System.out.println("     VisaoBranco   -> corpo=Original, memoria=Ausente,  consc=Branco");

        printFooter();
    }

    private void displayQC5() {
        printHeader("QC5 - Qual Visão é a mesma PESSOA por continuidade psicológica?");

        OWLNamedIndividual visaoOriginal = factory.getOWLNamedIndividual(IRI.create(NS + "VisaoOriginal"));

        System.out.println("\n  🧠 Identidade sob critério PSICOLÓGICO (mesmaPessoaPorMemoria):\n");
        System.out.println("  " + "-".repeat(80));

        Set<OWLNamedIndividual> mesmos = getRelated(visaoOriginal, propMesmaPessoaPorMemoria);
        mesmos.addAll(getRelatedInverse(visaoOriginal, propMesmaPessoaPorMemoria));

        System.out.printf("%n  Visão original: %s%n", getName(visaoOriginal));

        System.out.println("\n  Pares afirmados (mesmaPessoaPorMemoria):");
        if (mesmos.isEmpty()) {
            System.out.println("     (nenhum)");
        } else {
            for (OWLNamedIndividual v : mesmos) {
                System.out.printf("     • %s  ≡  %s%n",
                    getName(visaoOriginal), getName(v));

                Set<OWLNamedIndividual> memOrig = getRelated(visaoOriginal, propTemMemoria);
                Set<OWLNamedIndividual> memOutro = getRelated(v, propTemMemoria);
                Set<OWLNamedIndividual> intersec = new HashSet<>(memOrig);
                intersec.retainAll(memOutro);
                if (!intersec.isEmpty()) {
                    System.out.print("       Memória compartilhada: ");
                    for (OWLNamedIndividual m : intersec) {
                        System.out.print("[" + getName(m) + "] ");
                    }
                    System.out.println();
                }
            }
        }

        System.out.println("\n  📌 Interpretação (Locke):");
        System.out.println("     O Visão do Hex compartilha as memórias e a");
        System.out.println("     personalidade do Visão original. Sob o critério");
        System.out.println("     da continuidade psicológica, ele é a mesma PESSOA.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC6() {
        printHeader("QC6 - Qual Visão é a mesma PESSOA por continuidade material?");

        OWLNamedIndividual visaoOriginal = factory.getOWLNamedIndividual(IRI.create(NS + "VisaoOriginal"));

        System.out.println("\n  🦾 Identidade sob critério MATERIAL (mesmaPessoaPorCorpo):\n");
        System.out.println("  " + "-".repeat(80));

        Set<OWLNamedIndividual> mesmos = getRelated(visaoOriginal, propMesmaPessoaPorCorpo);
        mesmos.addAll(getRelatedInverse(visaoOriginal, propMesmaPessoaPorCorpo));

        System.out.printf("%n  Visão original: %s%n", getName(visaoOriginal));

        System.out.println("\n  Pares afirmados (mesmaPessoaPorCorpo):");
        if (mesmos.isEmpty()) {
            System.out.println("     (nenhum)");
        } else {
            for (OWLNamedIndividual v : mesmos) {
                System.out.printf("     • %s  ≡  %s%n",
                    getName(visaoOriginal), getName(v));

                Set<OWLNamedIndividual> corpoOrig = getRelated(visaoOriginal, propTemCorpo);
                Set<OWLNamedIndividual> corpoOutro = getRelated(v, propTemCorpo);
                Set<OWLNamedIndividual> intersec = new HashSet<>(corpoOrig);
                intersec.retainAll(corpoOutro);
                if (!intersec.isEmpty()) {
                    System.out.print("       Corpo compartilhado: ");
                    for (OWLNamedIndividual c : intersec) {
                        System.out.print("[" + getName(c) + "] ");
                    }
                    System.out.println();
                }
            }
        }

        System.out.println("\n  📌 Interpretação (materialismo):");
        System.out.println("     O Visão Branco possui o corpo físico original");
        System.out.println("     do Visão. Sob o critério da continuidade material,");
        System.out.println("     ele é a mesma PESSOA.");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayQC7() {
        printHeader("QC7 - Algum Visão é numericamente idêntico (owl:sameAs) ao original?");

        Set<OWLNamedIndividual> visoes = getVisions();

        System.out.println("\n  🔍 Identidade numérica global (owl:sameAs / owl:differentFrom):\n");
        System.out.println("  " + "-".repeat(80));

        for (OWLNamedIndividual visao : visoes) {
            String nome = getName(visao);

            System.out.printf("%n  👤 %s%n", nome);

            Set<OWLNamedIndividual> same = getSameIndividuals(visao);
            System.out.print("     owl:sameAs:       ");
            if (same.isEmpty()) System.out.println("(nenhum)");
            else {
                for (OWLNamedIndividual s : same) System.out.print("[" + getName(s) + "] ");
                System.out.println();
            }

            Set<OWLNamedIndividual> diff = getDifferentIndividuals(visao);
            System.out.print("     owl:differentFrom: ");
            if (diff.isEmpty()) System.out.println("(nenhum)");
            else {
                for (OWLNamedIndividual d : diff) System.out.print("[" + getName(d) + "] ");
                System.out.println();
            }
        }

        System.out.println("\n  " + "-".repeat(80));
        System.out.println("\n  📌 Interpretação:");
        System.out.println("     Nenhum Visão é numericamente idêntico ao original.");
        System.out.println("     As identidades afirmadas são SORTAIS (por memória,");
        System.out.println("     por corpo), não numéricas. Isso é exatamente o que");
        System.out.println("     dissolve o paradoxo: cada critério produz uma");
        System.out.println("     resposta diferente, e a ontologia permanece");
        System.out.println("     consistente porque separa os critérios.");
        System.out.println("\n     VisaoHex    owl:sameAs VisaoOriginal = false");
        System.out.println("     VisaoBranco owl:sameAs VisaoOriginal = false");
        System.out.println("     VisaoHex    owl:sameAs VisaoBranco   = false");
        System.out.println("     VisaoHex    owl:differentFrom VisaoBranco = true");

        System.out.println("  " + "-".repeat(80));
        printFooter();
    }

    private void displayStatistics() {
        printHeader("📊 ESTATÍSTICAS DA TESEUVISION-ONTOLOGY");

        int totalShips = getShips().size();
        int totalPlanks = getPlanks().size();
        int totalAggregates = getAggregates().size();
        int totalVisions = getVisions().size();
        int totalBodies = getBodies().size();
        int totalMemories = getMemories().size();
        int totalConsciousness = getConsciousness().size();

        System.out.println("  +-------------------------------------------------------+");
        System.out.printf("  |  Axiomas:                %-40d |%n", ontology.getAxiomCount());
        System.out.printf("  |  Classes:                %-40d |%n", ontology.getClassesInSignature().size());
        System.out.printf("  |  Indivíduos:             %-40d |%n", ontology.getIndividualsInSignature().size());
        System.out.printf("  |  Propriedades de Objeto: %-40d |%n", ontology.getObjectPropertiesInSignature().size());
        System.out.printf("  |  Propriedades de Dados:  %-40d |%n", ontology.getDataPropertiesInSignature().size());
        System.out.println("  +-------------------------------------------------------+");

        System.out.println("\n  📋 Indivíduos por Tipo:");
        System.out.printf("     - Navios:            %d%n", totalShips);
        System.out.printf("     - Tábuas:            %d%n", totalPlanks);
        System.out.printf("     - Agregados:         %d%n", totalAggregates);
        System.out.printf("     - Visões:            %d%n", totalVisions);
        System.out.printf("     - Corpos:            %d%n", totalBodies);
        System.out.printf("     - Memórias:          %d%n", totalMemories);
        System.out.printf("     - Consciências:      %d%n", totalConsciousness);

        int totalTemParte = 0, totalEParteDe = 0;
        int totalEConstituidoPor = 0, totalConstitui = 0, totalSubstitui = 0;
        int totalTemMemoria = 0, totalTemConsciencia = 0, totalTemCorpo = 0;
        int totalMesmoNavio = 0, totalMesmaMateria = 0;
        int totalMesmaPessoaMem = 0, totalMesmaPessoaCorpo = 0;
        int totalSame = 0, totalDifferent = 0;

        for (OWLNamedIndividual ind : ontology.getIndividualsInSignature()) {
            totalTemParte += getRelated(ind, propTemParte).size();
            totalEParteDe += getRelated(ind, propEParteDe).size();
            totalEConstituidoPor += getRelated(ind, propEConstituidoPor).size();
            totalConstitui += getRelated(ind, propConstitui).size();
            totalSubstitui += getRelated(ind, propSubstitui).size();
            totalTemMemoria += getRelated(ind, propTemMemoria).size();
            totalTemConsciencia += getRelated(ind, propTemConsciencia).size();
            totalTemCorpo += getRelated(ind, propTemCorpo).size();
            totalMesmoNavio += getRelated(ind, propMesmoNavioQue).size();
            totalMesmaMateria += getRelated(ind, propTemMesmaMateriaQue).size();
            totalMesmaPessoaMem += getRelated(ind, propMesmaPessoaPorMemoria).size();
            totalMesmaPessoaCorpo += getRelated(ind, propMesmaPessoaPorCorpo).size();
            totalSame += getSameIndividuals(ind).size();
            totalDifferent += getDifferentIndividuals(ind).size();
        }

        System.out.println("\n  🔗 Relacionamentos:");
        System.out.printf("     - temParte:               %d%n", totalTemParte);
        System.out.printf("     - eParteDe:               %d%n", totalEParteDe);
        System.out.printf("     - eConstituidoPor:        %d%n", totalEConstituidoPor);
        System.out.printf("     - constitui:              %d%n", totalConstitui);
        System.out.printf("     - substitui:              %d%n", totalSubstitui);
        System.out.printf("     - temMemoria:             %d%n", totalTemMemoria);
        System.out.printf("     - temConsciencia:         %d%n", totalTemConsciencia);
        System.out.printf("     - temCorpo:               %d%n", totalTemCorpo);
        System.out.printf("     - mesmoNavioQue:          %d%n", totalMesmoNavio);
        System.out.printf("     - temMesmaMateriaQue:     %d%n", totalMesmaMateria);
        System.out.printf("     - mesmaPessoaPorMemoria:  %d%n", totalMesmaPessoaMem);
        System.out.printf("     - mesmaPessoaPorCorpo:    %d%n", totalMesmaPessoaCorpo);
        System.out.printf("     - owl:sameAs:             %d%n", totalSame);
        System.out.printf("     - owl:differentFrom:      %d%n", totalDifferent);

        System.out.println("\n  🎬 Referências principais:");
        System.out.println("     Plutarco. Vidas Paralelas: Teseu. c. 100 d.C.");
        System.out.println("     Hobbes, T. (1651). Leviathan. London: Andrew Crooke.");
        System.out.println("     Locke, J. (1690). An Essay Concerning Human Understanding.");
        System.out.println("     Parfit, D. (1984). Reasons and Persons. Oxford Univ. Press.");
        System.out.println("     Wiggins, D. (1980). Sameness and Substance. Harvard Univ. Press.");
        System.out.println("     Schaeffer, J. (2021). WandaVision. Marvel Studios / Disney+.");
        printFooter();
    }

    // ============================================================
    // GERAR PDF
    // ============================================================
    private void generatePDF() {
        printHeader("📄 GERANDO PDF DA ONTOLOGIA");
        System.out.println("\n  ⏳ Gerando PDF com todas as questões de competência...\n");

        try {
            if (this.ontology == null) {
                System.out.println("  ❌ Ontologia não carregada. Não é possível gerar o PDF.");
                return;
            }

            TeseuVisionPDFGenerator pdfGenerator = new TeseuVisionPDFGenerator(this.ontology);
            pdfGenerator.generatePDF(PDF_OUTPUT_PATH);

            System.out.println("\n  ✅ PDF gerado com sucesso!");
            System.out.println("  📁 " + PDF_OUTPUT_PATH);
            System.out.println("\n  📊 Estatísticas do PDF:");
            System.out.println("     - 7 Questões de Competência");
            System.out.println("     - " + getShips().size() + " Navios");
            System.out.println("     - " + getPlanks().size() + " Tábuas");
            System.out.println("     - " + getVisions().size() + " Visões");
            System.out.println("     - Baseado no paradoxo do Navio de Teseu + WandaVision (2021)");

        } catch (Exception e) {
            System.err.println("\n  ❌ Erro ao gerar PDF: " + e.getMessage());
            e.printStackTrace();
        }
        printFooter();
    }

    // ============================================================
    // MENU PRINCIPAL
    // ============================================================
    private void showMenu() {
        int option;
        do {
            clearScreen();
            printHeader("⚓ TeseuVision-Ontology - Sistema de Consultas");
            System.out.println(" Baseado em: Navio de Teseu + WandaVision (Marvel, 2021)");
            System.out.println(" Arquivo: " + ONTOLOGY_PATH);
            System.out.println(SEPARATOR);
            System.out.println("  +-----------------------------------------------------------------------+");
            System.out.println("  |  1  QC1 - Quais navios participam do paradoxo?                       |");
            System.out.println("  |  2  QC2 - Qual navio é o mesmo NAVIO que o original?                 |");
            System.out.println("  |  3  QC3 - Qual navio tem a mesma MATÉRIA que o original?             |");
            System.out.println("  |  4  QC4 - Quais são as dimensões constitutivas de cada Visão?        |");
            System.out.println("  |  5  QC5 - Qual Visão é a mesma PESSOA por continuidade psicológica?  |");
            System.out.println("  |  6  QC6 - Qual Visão é a mesma PESSOA por continuidade material?     |");
            System.out.println("  |  7  QC7 - Algum Visão é numericamente idêntico ao original?          |");
            System.out.println("  |  8  Estatísticas da ontologia                                        |");
            System.out.println("  |  9  📄 GERAR PDF com todas as questões                               |");
            System.out.println("  |  0  Sair                                                              |");
            System.out.println("  +-----------------------------------------------------------------------+");
            System.out.print("\n  Escolha uma opção: ");

            try {
                option = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                option = -1;
            }

            System.out.println();

            switch (option) {
                case 1: displayQC1(); waitForEnter(); break;
                case 2: displayQC2(); waitForEnter(); break;
                case 3: displayQC3(); waitForEnter(); break;
                case 4: displayQC4(); waitForEnter(); break;
                case 5: displayQC5(); waitForEnter(); break;
                case 6: displayQC6(); waitForEnter(); break;
                case 7: displayQC7(); waitForEnter(); break;
                case 8: displayStatistics(); waitForEnter(); break;
                case 9: generatePDF(); waitForEnter(); break;
                case 0:
                    System.out.println(ANSI_GREEN + "Obrigado por usar a TeseuVision-Ontology!" + ANSI_RESET);
                    break;
                default:
                    System.out.println(ANSI_YELLOW + "Opção inválida! Digite um número entre 0 e 9." + ANSI_RESET);
                    waitForEnter();
                    break;
            }
        } while (option != 0);
        scanner.close();
    }

    private void printHeader(String title) {
        System.out.println(SEPARATOR);
        System.out.println(ANSI_CYAN + ANSI_BOLD + title + ANSI_RESET);
        System.out.println(SEPARATOR);
    }

    private void printFooter() {
        System.out.println(SEPARATOR);
    }

    private void waitForEnter() {
        System.out.print(ANSI_YELLOW + "\nPressione ENTER para voltar ao menu..." + ANSI_RESET);
        scanner.nextLine();
        System.out.println();
    }

    private void clearScreen() {
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
        } catch (Exception e) {
            for (int i = 0; i < 50; i++) System.out.println();
        }
    }

    public static void main(String[] args) {
        new TeseuVisionConsultas();
    }
}