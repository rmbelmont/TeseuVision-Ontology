package br.unirio.teseuvision;

import java.io.File;
import java.util.*;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.RDFXMLDocumentFormat;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.util.DefaultPrefixManager;

/**
 * TeseuVision-Ontology - Ontologia para o Paradoxo do Navio de Teseu
 * e a Crise de Identidade do Visão em "WandaVision" (2021)
 *
 * Baseada em:
 *  - Paradoxo do Navio de Teseu (Plutarco, Hobbes)
 *  - WandaVision (Marvel Studios, 2021)
 *  - Teorias da Identidade Pessoal (Locke, Parfit)
 *  - Relatividade Sortal (Wiggins, Strawson)
 *  - Metodologia OntoView (Klein et al., 2002)
 *
 * Questões de Competência:
 * QC1: Quais navios participam do paradoxo?
 * QC2: Qual navio é o mesmo NAVIO que o original?
 * QC3: Qual navio tem a mesma MATÉRIA que o original?
 * QC4: Quais são as dimensões constitutivas de cada Visão?
 * QC5: Qual Visão é a mesma PESSOA por continuidade psicológica?
 * QC6: Qual Visão é a mesma PESSOA por continuidade material?
 * QC7: Algum dos Visões é numericamente idêntico (owl:sameAs) ao original?
 */
public class TeseuVisionOntology {

    private static final String NS = "http://www.unirio.br/teseuvision/ontology#";
    private static final String BASE = "http://www.unirio.br/teseuvision/ontology";
    private static final String OUTPUT_DIR = "./ontology/";

    private static final String ANSI_RESET = "\u001B[0m";
    private static final String ANSI_BOLD = "\u001B[1m";
    private static final String ANSI_CYAN = "\u001B[36m";
    private static final String ANSI_GREEN = "\u001B[32m";
    private static final String ANSI_YELLOW = "\u001B[33m";
    private static final String ANSI_RED = "\u001B[31m";

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private DefaultPrefixManager prefixManager;

    // ============================================================
    // CLASSES PRINCIPAIS
    // ============================================================
    private OWLClass classEntidade;
    private OWLClass classObjetoFisico;
    private OWLClass classArtefato;
    private OWLClass classParteTemporal;
    private OWLClass classCriterioIdentidade;

    // ============================================================
    // NAVIO DE TESEU - QC1 / QC2 / QC3
    // ============================================================
    private OWLClass classNavio;
    private OWLClass classTabua;
    private OWLClass classAgregadoMaterial;

    // ============================================================
    // PESSOAS E SUAS DIMENSÕES - QC4
    // ============================================================
    private OWLClass classPessoa;
    private OWLClass classSerSintetico;
    private OWLClass classMemoria;
    private OWLClass classConsciencia;
    private OWLClass classCorpo;

    // ============================================================
    // SUBCLASSES DE IDENTIDADE - QC5 / QC6 / QC7
    // ============================================================
    private OWLClass classCorpoOriginal;
    private OWLClass classCorpoReconstruido;
    private OWLClass classMemoriaOriginal;
    private OWLClass classMemoriaAusente;
    private OWLClass classConscienciaOriginal;
    private OWLClass classConscienciaHex;
    private OWLClass classConscienciaBranco;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propTemParte;
    private OWLObjectProperty propEParteDe;
    private OWLObjectProperty propEConstituidoPor;
    private OWLObjectProperty propConstitui;
    private OWLObjectProperty propSubstitui;
    private OWLObjectProperty propTemMemoria;
    private OWLObjectProperty propTemConsciencia;
    private OWLObjectProperty propTemCorpo;
    private OWLObjectProperty propMesmoNavioQue;
    private OWLObjectProperty propTemMesmaMateriaQue;
    private OWLObjectProperty propMesmaPessoaPorMemoria;
    private OWLObjectProperty propMesmaPessoaPorCorpo;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphHasYear;
    private OWLDataProperty dphHasCanonicalStatus;
    private OWLDataProperty dphHasCriterioAdotado;
    private OWLDataProperty dphHasFonte;   // <-- CORRIGIDO (antes: dphHasSource)

    public TeseuVisionOntology() {
        try {
            this.manager = OWLManager.createOWLOntologyManager();
            this.factory = manager.getOWLDataFactory();

            this.prefixManager = new DefaultPrefixManager(NS);
            prefixManager.setPrefix("owl", "http://www.w3.org/2002/07/owl#");
            prefixManager.setPrefix("rdf", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
            prefixManager.setPrefix("rdfs", "http://www.w3.org/2000/01/rdf-schema#");
            prefixManager.setPrefix("xsd", "http://www.w3.org/2001/XMLSchema#");

            IRI ontologyIRI = IRI.create(BASE);
            this.ontology = manager.createOntology(ontologyIRI);

            System.out.println(ANSI_CYAN + "╔═══════════════════════════════════════════════════════════════════════════════╗" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║" + ANSI_BOLD + "  ⚓ TeseuVision-Ontology v1.0" + ANSI_RESET + ANSI_CYAN + "                                                 ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🎬 Baseada em WandaVision (Marvel, 2021) e no Navio de Teseu" + ANSI_CYAN + "                ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🧠 Identidade Diacrônica | Relatividade Sortal | Metafísica" + ANSI_CYAN + "                 ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  📈 7 Questões de Competência (QC1 a QC7)" + ANSI_CYAN + "                                    ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "║  🚢 3 navios | 3 Visões | 2 critérios de identidade pessoal" + ANSI_CYAN + "                  ║" + ANSI_RESET);
            System.out.println(ANSI_CYAN + "╚═══════════════════════════════════════════════════════════════════════════════╝" + ANSI_RESET);

            build();
            System.out.println(ANSI_GREEN + "\n✅ Ontologia construída com sucesso!" + ANSI_RESET);

        } catch (OWLOntologyCreationException e) {
            e.printStackTrace();
        }
    }

    private void build() {
        createClasses();
        defineClassHierarchy();
        createObjectProperties();
        createDataProperties();
        definePropertyCharacteristics();
        createAggregateIndividuals();
        createPlankIndividuals();
        createShipIndividuals();
        createBodyIndividuals();
        createMemoryIndividuals();
        createConsciousnessIndividuals();
        createVisionIndividuals();
        createRelationships();
        addAxioms();
    }

    private void createClasses() {
        // Classes principais
        classEntidade = createClass("Entidade");
        classObjetoFisico = createClass("ObjetoFisico");
        classArtefato = createClass("Artefato");
        classParteTemporal = createClass("ParteTemporal");
        classCriterioIdentidade = createClass("CriterioIdentidade");

        // Navio de Teseu (QC1 / QC2 / QC3)
        classNavio = createClass("Navio");
        classTabua = createClass("Tabua");
        classAgregadoMaterial = createClass("AgregadoMaterial");

        // Pessoas e dimensões (QC4)
        classPessoa = createClass("Pessoa");
        classSerSintetico = createClass("SerSintetico");
        classMemoria = createClass("Memoria");
        classConsciencia = createClass("Consciencia");
        classCorpo = createClass("Corpo");

        // Subclasses de identidade (QC5 / QC6 / QC7)
        classCorpoOriginal = createClass("CorpoOriginal");
        classCorpoReconstruido = createClass("CorpoReconstruido");
        classMemoriaOriginal = createClass("MemoriaOriginal");
        classMemoriaAusente = createClass("MemoriaAusente");
        classConscienciaOriginal = createClass("ConscienciaOriginal");
        classConscienciaHex = createClass("ConscienciaHex");
        classConscienciaBranco = createClass("ConscienciaBranco");
    }

    private void defineClassHierarchy() {
        // Eixo ontológico
        addSubClass(classObjetoFisico, classEntidade);
        addSubClass(classArtefato, classObjetoFisico);
        addSubClass(classNavio, classArtefato);
        addSubClass(classTabua, classObjetoFisico);
        addSubClass(classAgregadoMaterial, classObjetoFisico);
        addSubClass(classParteTemporal, classEntidade);
        addSubClass(classCriterioIdentidade, classEntidade);

        // Pessoas
        addSubClass(classSerSintetico, classPessoa);
        addSubClass(classMemoria, classEntidade);
        addSubClass(classConsciencia, classEntidade);
        addSubClass(classCorpo, classObjetoFisico);

        // Subclasses de identidade
        addSubClass(classCorpoOriginal, classCorpo);
        addSubClass(classCorpoReconstruido, classCorpo);
        addSubClass(classMemoriaOriginal, classMemoria);
        addSubClass(classMemoriaAusente, classMemoria);
        addSubClass(classConscienciaOriginal, classConsciencia);
        addSubClass(classConscienciaHex, classConsciencia);
        addSubClass(classConscienciaBranco, classConsciencia);

        // Disjunções fundamentais
        addDisjoint(classNavio, classTabua);
        addDisjoint(classPessoa, classNavio);
        addDisjoint(classMemoria, classConsciencia);
        addDisjoint(classMemoriaOriginal, classMemoriaAusente);
        addDisjoint(classCorpoOriginal, classCorpoReconstruido);
    }

    private void createObjectProperties() {
        // Mereologia e constituição
        propTemParte = createObjectProperty("temParte");
        propEParteDe = createObjectProperty("eParteDe");
        propEConstituidoPor = createObjectProperty("eConstituidoPor");
        propConstitui = createObjectProperty("constitui");
        propSubstitui = createObjectProperty("substitui");

        // Dimensões da pessoa
        propTemMemoria = createObjectProperty("temMemoria");
        propTemConsciencia = createObjectProperty("temConsciencia");
        propTemCorpo = createObjectProperty("temCorpo");

        // Identidades sortais relativas (NÃO são owl:sameAs)
        propMesmoNavioQue = createObjectProperty("mesmoNavioQue");
        propTemMesmaMateriaQue = createObjectProperty("temMesmaMateriaQue");
        propMesmaPessoaPorMemoria = createObjectProperty("mesmaPessoaPorMemoria");
        propMesmaPessoaPorCorpo = createObjectProperty("mesmaPessoaPorCorpo");
    }

    private void createDataProperties() {
        dphHasName = createDataProperty("hasName");
        dphHasDescription = createDataProperty("hasDescription");
        dphHasYear = createDataProperty("hasYear");
        dphHasCanonicalStatus = createDataProperty("hasCanonicalStatus");
        dphHasCriterioAdotado = createDataProperty("hasCriterioAdotado");
        dphHasFonte = createDataProperty("hasFonte");   // <-- CORRIGIDO (antes: hasSource)
    }

    private void definePropertyCharacteristics() {
        // Mesmo navio: simétrica, transitiva e reflexiva (identidade sob sortal Navio)
        manager.addAxiom(ontology,
            factory.getOWLSymmetricObjectPropertyAxiom(propMesmoNavioQue));
        manager.addAxiom(ontology,
            factory.getOWLTransitiveObjectPropertyAxiom(propMesmoNavioQue));
        manager.addAxiom(ontology,
            factory.getOWLReflexiveObjectPropertyAxiom(propMesmoNavioQue));

        // Mesma matéria: simétrica
        manager.addAxiom(ontology,
            factory.getOWLSymmetricObjectPropertyAxiom(propTemMesmaMateriaQue));

        // Mesma pessoa por memória: simétrica, reflexiva
        manager.addAxiom(ontology,
            factory.getOWLSymmetricObjectPropertyAxiom(propMesmaPessoaPorMemoria));
        manager.addAxiom(ontology,
            factory.getOWLReflexiveObjectPropertyAxiom(propMesmaPessoaPorMemoria));

        // Mesma pessoa por corpo: simétrica, reflexiva
        manager.addAxiom(ontology,
            factory.getOWLSymmetricObjectPropertyAxiom(propMesmaPessoaPorCorpo));
        manager.addAxiom(ontology,
            factory.getOWLReflexiveObjectPropertyAxiom(propMesmaPessoaPorCorpo));

        // Inversas
        manager.addAxiom(ontology,
            factory.getOWLInverseObjectPropertiesAxiom(propTemParte, propEParteDe));
        manager.addAxiom(ontology,
            factory.getOWLInverseObjectPropertiesAxiom(propEConstituidoPor, propConstitui));

        // Domínios e ranges das propriedades sortais
        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propMesmoNavioQue, classNavio));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propMesmoNavioQue, classNavio));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propMesmaPessoaPorMemoria, classPessoa));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propMesmaPessoaPorMemoria, classPessoa));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propMesmaPessoaPorCorpo, classPessoa));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propMesmaPessoaPorCorpo, classPessoa));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propTemMemoria, classPessoa));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propTemMemoria, classMemoria));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propTemCorpo, classPessoa));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propTemCorpo, classCorpo));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propTemConsciencia, classPessoa));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propTemConsciencia, classConsciencia));

        manager.addAxiom(ontology, factory.getOWLObjectPropertyDomainAxiom(
            propEConstituidoPor, classObjetoFisico));
        manager.addAxiom(ontology, factory.getOWLObjectPropertyRangeAxiom(
            propEConstituidoPor, classAgregadoMaterial));
    }

    // ============================================================
    // AGREGADOS MATERIAIS
    // ============================================================
    private void createAggregateIndividuals() {
        OWLNamedIndividual agOriginal = createIndividual("AgregadoOriginal", classAgregadoMaterial);
        addDataProperty(agOriginal, dphHasName, "Agregado Material Original");
        addDataProperty(agOriginal, dphHasDescription,
            "Soma mereológica das tábuas originais do Navio de Teseu");
        addDataProperty(agOriginal, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");

        OWLNamedIndividual agNovo = createIndividual("AgregadoNovo", classAgregadoMaterial);
        addDataProperty(agNovo, dphHasName, "Agregado Material Novo");
        addDataProperty(agNovo, dphHasDescription,
            "Soma mereológica das tábuas novas do Navio A");
        addDataProperty(agNovo, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");
    }

    // ============================================================
    // TÁBUAS - partes dos navios
    // ============================================================
    private void createPlankIndividuals() {
        String[] originais = {"Tabua1", "Tabua2", "Tabua3"};
        for (String id : originais) {
            OWLNamedIndividual t = createIndividual(id, classTabua);
            addDataProperty(t, dphHasName, id + " (original)");
            addDataProperty(t, dphHasDescription, "Tábua original do Navio de Teseu");
            addDataProperty(t, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");
        }

        String[] novas = {"Tabua1Nova", "Tabua2Nova", "Tabua3Nova"};
        for (String id : novas) {
            OWLNamedIndividual t = createIndividual(id, classTabua);
            addDataProperty(t, dphHasName, id + " (nova)");
            addDataProperty(t, dphHasDescription, "Tábua de substituição do Navio A");
            addDataProperty(t, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");
        }
    }

    // ============================================================
    // NAVIOS - QC1 / QC2 / QC3
    // ============================================================
    private void createShipIndividuals() {
        OWLNamedIndividual navioOriginal = createIndividual("NavioOriginal", classNavio);
        addDataProperty(navioOriginal, dphHasName, "Navio de Teseu (original)");
        addDataProperty(navioOriginal, dphHasDescription,
            "Navio no qual Teseu retornou de Creta, preservado pelos atenienses");
        addDataProperty(navioOriginal, dphHasYear, "-1300");
        addDataProperty(navioOriginal, dphHasCanonicalStatus, "true");
        addDataProperty(navioOriginal, dphHasCriterioAdotado, "Material");
        addDataProperty(navioOriginal, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");

        OWLNamedIndividual navioA = createIndividual("NavioA", classNavio);
        addDataProperty(navioA, dphHasName, "Navio A (peças substituídas)");
        addDataProperty(navioA, dphHasDescription,
            "Navio reparado continuamente até que nenhuma tábua original restasse");
        addDataProperty(navioA, dphHasCanonicalStatus, "true");
        addDataProperty(navioA, dphHasCriterioAdotado, "Continuidade Causal");
        addDataProperty(navioA, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");

        OWLNamedIndividual navioB = createIndividual("NavioB", classNavio);
        addDataProperty(navioB, dphHasName, "Navio B (peças originais remontadas)");
        addDataProperty(navioB, dphHasDescription,
            "Navio remontado a partir das tábuas originais descartadas");
        addDataProperty(navioB, dphHasCanonicalStatus, "true");
        addDataProperty(navioB, dphHasCriterioAdotado, "Material");
        addDataProperty(navioB, dphHasFonte, "Plutarco, Vidas Paralelas: Teseu");
    }

    // ============================================================
    // CORPOS
    // ============================================================
    private void createBodyIndividuals() {
        OWLNamedIndividual corpoOrig = createIndividual("CorpoVisaoOriginal", classCorpoOriginal);
        addDataProperty(corpoOrig, dphHasName, "Corpo do Visão original");
        addDataProperty(corpoOrig, dphHasDescription,
            "Corpo sintético do Visão, com a Joia da Mente, antes de Infinity War");
        addDataProperty(corpoOrig, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual corpoRecon = createIndividual("CorpoVisaoBranco", classCorpoReconstruido);
        addDataProperty(corpoRecon, dphHasName, "Corpo do Visão Branco");
        addDataProperty(corpoRecon, dphHasDescription,
            "Corpo reconstruído pela S.W.O.R.D. a partir dos restos do Visão original");
        addDataProperty(corpoRecon, dphHasFonte, "WandaVision (2021)");
    }

    // ============================================================
    // MEMÓRIAS
    // ============================================================
    private void createMemoryIndividuals() {
        OWLNamedIndividual memOrig = createIndividual("MemoriaOriginal", classMemoriaOriginal);
        addDataProperty(memOrig, dphHasName, "Memórias do Visão original");
        addDataProperty(memOrig, dphHasDescription,
            "Conjunto de memórias, afetos e personalidade do Visão original");
        addDataProperty(memOrig, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual memAusente = createIndividual("MemoriaAusente", classMemoriaAusente);
        addDataProperty(memAusente, dphHasName, "Ausência de memórias (Visão Branco)");
        addDataProperty(memAusente, dphHasDescription,
            "Estado do Visão Branco: sem memórias, apenas programação da S.W.O.R.D.");
        addDataProperty(memAusente, dphHasFonte, "WandaVision (2021)");
    }

    // ============================================================
    // CONSCIÊNCIAS
    // ============================================================
    private void createConsciousnessIndividuals() {
        OWLNamedIndividual consOrig = createIndividual("ConscienciaOriginal", classConscienciaOriginal);
        addDataProperty(consOrig, dphHasName, "Consciência do Visão original");
        addDataProperty(consOrig, dphHasDescription,
            "Estado mental do Visão original antes da morte em Infinity War");
        addDataProperty(consOrig, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual consHex = createIndividual("ConscienciaHex", classConscienciaHex);
        addDataProperty(consHex, dphHasName, "Consciência do Visão do Hex");
        addDataProperty(consHex, dphHasDescription,
            "Consciência criada por Wanda no Hex, com memórias do Visão original");
        addDataProperty(consHex, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual consBranco = createIndividual("ConscienciaBranco", classConscienciaBranco);
        addDataProperty(consBranco, dphHasName, "Consciência do Visão Branco");
        addDataProperty(consBranco, dphHasDescription,
            "Consciência reativada pela S.W.O.R.D. sem memórias ou afetos");
        addDataProperty(consBranco, dphHasFonte, "WandaVision (2021)");
    }

    // ============================================================
    // VISÕES - QC4 / QC5 / QC6 / QC7
    // ============================================================
    private void createVisionIndividuals() {
        OWLNamedIndividual visaoOriginal = createIndividual("VisaoOriginal", classSerSintetico);
        addDataProperty(visaoOriginal, dphHasName, "Visão (original)");
        addDataProperty(visaoOriginal, dphHasDescription,
            "Sintozoide criado por Ultron e pela Joia da Mente, herói dos Vingadores");
        addDataProperty(visaoOriginal, dphHasYear, "2015");
        addDataProperty(visaoOriginal, dphHasCanonicalStatus, "true");
        addDataProperty(visaoOriginal, dphHasCriterioAdotado, "Continuidade Psicológica + Material");
        addDataProperty(visaoOriginal, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual visaoHex = createIndividual("VisaoHex", classSerSintetico);
        addDataProperty(visaoHex, dphHasName, "Visão do Hex");
        addDataProperty(visaoHex, dphHasDescription,
            "Visão criado por Wanda no Hex, com memórias e afetos do original");
        addDataProperty(visaoHex, dphHasYear, "2024");
        addDataProperty(visaoHex, dphHasCanonicalStatus, "true");
        addDataProperty(visaoHex, dphHasCriterioAdotado, "Continuidade Psicológica");
        addDataProperty(visaoHex, dphHasFonte, "WandaVision (2021)");

        OWLNamedIndividual visaoBranco = createIndividual("VisaoBranco", classSerSintetico);
        addDataProperty(visaoBranco, dphHasName, "Visão Branco");
        addDataProperty(visaoBranco, dphHasDescription,
            "Visão remontado pela S.W.O.R.D. com o corpo original, sem memórias");
        addDataProperty(visaoBranco, dphHasYear, "2024");
        addDataProperty(visaoBranco, dphHasCanonicalStatus, "true");
        addDataProperty(visaoBranco, dphHasCriterioAdotado, "Continuidade Material");
        addDataProperty(visaoBranco, dphHasFonte, "WandaVision (2021)");
    }

    // ============================================================
    // RELACIONAMENTOS
    // ============================================================
    private void createRelationships() {
        // ============================================================
        // NAVIO DE TESEU - constituição material
        // ============================================================
        addObjectProperty(getIndividual("NavioOriginal"),
            propEConstituidoPor, getIndividual("AgregadoOriginal"));
        addObjectProperty(getIndividual("NavioA"),
            propEConstituidoPor, getIndividual("AgregadoNovo"));
        addObjectProperty(getIndividual("NavioB"),
            propEConstituidoPor, getIndividual("AgregadoOriginal"));

        // ============================================================
        // Mereologia das partes
        // ============================================================
        addObjectProperty(getIndividual("AgregadoOriginal"), propTemParte, getIndividual("Tabua1"));
        addObjectProperty(getIndividual("AgregadoOriginal"), propTemParte, getIndividual("Tabua2"));
        addObjectProperty(getIndividual("AgregadoOriginal"), propTemParte, getIndividual("Tabua3"));

        addObjectProperty(getIndividual("AgregadoNovo"), propTemParte, getIndividual("Tabua1Nova"));
        addObjectProperty(getIndividual("AgregadoNovo"), propTemParte, getIndividual("Tabua2Nova"));
        addObjectProperty(getIndividual("AgregadoNovo"), propTemParte, getIndividual("Tabua3Nova"));

        // Inversas
        addObjectProperty(getIndividual("Tabua1"), propEParteDe, getIndividual("AgregadoOriginal"));
        addObjectProperty(getIndividual("Tabua2"), propEParteDe, getIndividual("AgregadoOriginal"));
        addObjectProperty(getIndividual("Tabua3"), propEParteDe, getIndividual("AgregadoOriginal"));
        addObjectProperty(getIndividual("Tabua1Nova"), propEParteDe, getIndividual("AgregadoNovo"));
        addObjectProperty(getIndividual("Tabua2Nova"), propEParteDe, getIndividual("AgregadoNovo"));
        addObjectProperty(getIndividual("Tabua3Nova"), propEParteDe, getIndividual("AgregadoNovo"));

        // ============================================================
        // Substituições das tábuas
        // ============================================================
        addObjectProperty(getIndividual("Tabua1Nova"), propSubstitui, getIndividual("Tabua1"));
        addObjectProperty(getIndividual("Tabua2Nova"), propSubstitui, getIndividual("Tabua2"));
        addObjectProperty(getIndividual("Tabua3Nova"), propSubstitui, getIndividual("Tabua3"));

        // ============================================================
        // QC2: Identidade sob sortal Navio
        // ============================================================
        addObjectProperty(getIndividual("NavioA"),
            propMesmoNavioQue, getIndividual("NavioOriginal"));

        // ============================================================
        // QC3: Identidade sob sortal Matéria
        // ============================================================
        addObjectProperty(getIndividual("NavioB"),
            propTemMesmaMateriaQue, getIndividual("NavioOriginal"));

        // Distinções numéricas (owl:differentFrom)
        manager.addAxiom(ontology, factory.getOWLDifferentIndividualsAxiom(
            getIndividual("NavioOriginal"),
            getIndividual("NavioA"),
            getIndividual("NavioB")));

        // ============================================================
        // QC4: Dimensões constitutivas dos Visões
        // ============================================================
        // Visão original: corpo, memória e consciência originais
        addObjectProperty(getIndividual("VisaoOriginal"),
            propTemCorpo, getIndividual("CorpoVisaoOriginal"));
        addObjectProperty(getIndividual("VisaoOriginal"),
            propTemMemoria, getIndividual("MemoriaOriginal"));
        addObjectProperty(getIndividual("VisaoOriginal"),
            propTemConsciencia, getIndividual("ConscienciaOriginal"));

        // Visão do Hex: memória original, consciência Hex, SEM corpo original
        addObjectProperty(getIndividual("VisaoHex"),
            propTemMemoria, getIndividual("MemoriaOriginal"));
        addObjectProperty(getIndividual("VisaoHex"),
            propTemConsciencia, getIndividual("ConscienciaHex"));

        // Visão Branco: corpo original, consciência Branco, SEM memória original
        addObjectProperty(getIndividual("VisaoBranco"),
            propTemCorpo, getIndividual("CorpoVisaoOriginal"));
        addObjectProperty(getIndividual("VisaoBranco"),
            propTemConsciencia, getIndividual("ConscienciaBranco"));
        addObjectProperty(getIndividual("VisaoBranco"),
            propTemMemoria, getIndividual("MemoriaAusente"));

        // ============================================================
        // QC5: Identidade psicológica
        // ============================================================
        addObjectProperty(getIndividual("VisaoHex"),
            propMesmaPessoaPorMemoria, getIndividual("VisaoOriginal"));

        // ============================================================
        // QC6: Identidade material
        // ============================================================
        addObjectProperty(getIndividual("VisaoBranco"),
            propMesmaPessoaPorCorpo, getIndividual("VisaoOriginal"));

        // Distinções numéricas (owl:differentFrom)
        manager.addAxiom(ontology, factory.getOWLDifferentIndividualsAxiom(
            getIndividual("VisaoOriginal"),
            getIndividual("VisaoHex"),
            getIndividual("VisaoBranco")));
    }

    private void addAxioms() {
        // ============================================================
        // Classes definidas por equivalência
        // Navio ≡ Artefato and (eConstituidoPor some AgregadoMaterial)
        // ============================================================
        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classNavio,
            factory.getOWLObjectIntersectionOf(
                classArtefato,
                factory.getOWLObjectSomeValuesFrom(propEConstituidoPor, classAgregadoMaterial))));

        // SerSintetico ≡ Pessoa and (temCorpo some Corpo)
        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classSerSintetico,
            factory.getOWLObjectIntersectionOf(
                classPessoa,
                factory.getOWLObjectSomeValuesFrom(propTemCorpo, classCorpo))));

        // MemoriaAusente ≡ Memoria and (hasName value "Ausência de memórias (Visão Branco)")
        manager.addAxiom(ontology, factory.getOWLEquivalentClassesAxiom(
            classMemoriaAusente,
            factory.getOWLObjectIntersectionOf(
                classMemoria,
                factory.getOWLDataHasValue(dphHasName,
                    factory.getOWLLiteral("Ausência de memórias (Visão Branco)")))));
    }

    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================
    private OWLClass createClass(String name) {
        OWLClass cls = factory.getOWLClass(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(cls));
        return cls;
    }

    private void addSubClass(OWLClass sub, OWLClass sup) {
        manager.addAxiom(ontology, factory.getOWLSubClassOfAxiom(sub, sup));
    }

    private void addDisjoint(OWLClass a, OWLClass b) {
        manager.addAxiom(ontology, factory.getOWLDisjointClassesAxiom(a, b));
    }

    private OWLObjectProperty createObjectProperty(String name) {
        OWLObjectProperty prop = factory.getOWLObjectProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLDataProperty createDataProperty(String name) {
        OWLDataProperty prop = factory.getOWLDataProperty(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(prop));
        return prop;
    }

    private OWLNamedIndividual createIndividual(String name, OWLClass cls) {
        OWLNamedIndividual individual = factory.getOWLNamedIndividual(IRI.create(NS + name));
        manager.addAxiom(ontology, factory.getOWLDeclarationAxiom(individual));
        manager.addAxiom(ontology, factory.getOWLClassAssertionAxiom(cls, individual));
        return individual;
    }

    private OWLNamedIndividual getIndividual(String name) {
        return factory.getOWLNamedIndividual(IRI.create(NS + name));
    }

    private void addObjectProperty(OWLNamedIndividual subject, OWLObjectProperty prop, OWLNamedIndividual object) {
        if (subject != null && object != null) {
            manager.addAxiom(ontology, factory.getOWLObjectPropertyAssertionAxiom(prop, subject, object));
        }
    }

    private void addDataProperty(OWLNamedIndividual individual, OWLDataProperty prop, String value) {
        if (individual != null && value != null) {
            OWLLiteral literal = factory.getOWLLiteral(value);
            manager.addAxiom(ontology, factory.getOWLDataPropertyAssertionAxiom(prop, individual, literal));
        }
    }

    public void saveOntology(String outputDir) {
        try {
            File dir = new File(outputDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String filePath = outputDir + "/teseuvision-ontology.rdf";
            OWLDocumentFormat documentFormat = new RDFXMLDocumentFormat();

            File file = new File(filePath);
            manager.saveOntology(ontology, documentFormat, IRI.create(file));

            System.out.println(ANSI_GREEN + "\n📁 Ontologia salva em: " + file.getAbsolutePath() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Axiomas: " + ontology.getAxiomCount() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Classes: " + ontology.getClassesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Objeto: " + ontology.getObjectPropertiesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Propriedades de Dados: " + ontology.getDataPropertiesInSignature().size() + ANSI_RESET);
            System.out.println(ANSI_CYAN + "   Indivíduos: " + ontology.getIndividualsInSignature().size() + ANSI_RESET);

        } catch (Exception e) {
            System.err.println("Erro ao salvar ontologia: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ============================================================
    // CONSULTAS QC1-QC7
    // ============================================================
    public void runCompetencyQuestions() {
        System.out.println("\n" + ANSI_CYAN + "═══════════════════════════════════════════════════════════════" + ANSI_RESET);
        System.out.println(ANSI_BOLD + "  📊 QUESTÕES DE COMPETÊNCIA (QC1-QC7)" + ANSI_RESET);
        System.out.println(ANSI_CYAN + "═══════════════════════════════════════════════════════════════" + ANSI_RESET);

        // QC1
        System.out.println(ANSI_YELLOW + "\n[QC1] Quais navios participam do paradoxo?" + ANSI_RESET);
        System.out.println("  • NavioOriginal");
        System.out.println("  • NavioA        (peças substituídas continuamente)");
        System.out.println("  • NavioB        (remontado com peças originais)");

        // QC2
        System.out.println(ANSI_YELLOW + "\n[QC2] Qual navio é o mesmo NAVIO que o original?" + ANSI_RESET);
        System.out.println("  mesmoNavioQue(NavioA, NavioOriginal) = true");
        System.out.println("  mesmoNavioQue(NavioB, NavioOriginal) = false");
        System.out.println("  → NavioA é o mesmo NAVIO (continuidade causal/funcional)");

        // QC3
        System.out.println(ANSI_YELLOW + "\n[QC3] Qual navio tem a mesma MATÉRIA que o original?" + ANSI_RESET);
        System.out.println("  temMesmaMateriaQue(NavioB, NavioOriginal) = true");
        System.out.println("  temMesmaMateriaQue(NavioA, NavioOriginal) = false");
        System.out.println("  → NavioB tem a mesma MATÉRIA (mesmas tábuas)");

        // QC4
        System.out.println(ANSI_YELLOW + "\n[QC4] Quais são as dimensões constitutivas de cada Visão?" + ANSI_RESET);
        System.out.println("  VisaoOriginal -> corpo=Original, memoria=Original, consc=Original");
        System.out.println("  VisaoHex      -> corpo=Ausente,  memoria=Original, consc=Hex");
        System.out.println("  VisaoBranco   -> corpo=Original, memoria=Ausente,  consc=Branco");

        // QC5
        System.out.println(ANSI_YELLOW + "\n[QC5] Qual Visão é a mesma PESSOA por continuidade psicológica?" + ANSI_RESET);
        System.out.println("  mesmaPessoaPorMemoria(VisaoHex, VisaoOriginal) = true");
        System.out.println("  → VisaoHex é o mesmo sob o critério psicológico (Locke)");

        // QC6
        System.out.println(ANSI_YELLOW + "\n[QC6] Qual Visão é a mesma PESSOA por continuidade material?" + ANSI_RESET);
        System.out.println("  mesmaPessoaPorCorpo(VisaoBranco, VisaoOriginal) = true");
        System.out.println("  → VisaoBranco é o mesmo sob o critério material");

        // QC7
        System.out.println(ANSI_YELLOW + "\n[QC7] Algum Visão é numericamente idêntico (owl:sameAs) ao original?" + ANSI_RESET);
        System.out.println("  VisaoHex    owl:sameAs VisaoOriginal = false");
        System.out.println("  VisaoBranco owl:sameAs VisaoOriginal = false");
        System.out.println("  VisaoHex    owl:sameAs VisaoBranco   = false");
        System.out.println("  VisaoHex    owl:differentFrom VisaoBranco = true");
        System.out.println("  → Nenhum é numericamente idêntico; ontologia permanece consistente");

        System.out.println(ANSI_CYAN + "\n═══════════════════════════════════════════════════════════════" + ANSI_RESET);
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            TeseuVisionOntology builder = new TeseuVisionOntology();
            builder.saveOntology(OUTPUT_DIR);
            builder.runCompetencyQuestions();

            System.out.println("\n" + ANSI_GREEN + "✅ Ontologia construída e salva com sucesso!" + ANSI_RESET);

            System.out.println("\n" + ANSI_CYAN + "📊 Estatísticas da TeseuVision-Ontology:" + ANSI_RESET);
            System.out.println("   Navios: 3 (Original, A, B)");
            System.out.println("   Tábuas: 6 (3 originais + 3 novas)");
            System.out.println("   Agregados materiais: 2 (Original, Novo)");
            System.out.println("   Visões: 3 (Original, Hex, Branco)");
            System.out.println("   Corpos: 2 (Original, Reconstruído)");
            System.out.println("   Memórias: 2 (Original, Ausente)");
            System.out.println("   Consciências: 3 (Original, Hex, Branco)");
            System.out.println("\n   ✅ 7 Questões de Competência implementadas:");
            System.out.println("      QC1: Navios participantes (instâncias de Navio)");
            System.out.println("      QC2: Identidade sob sortal Navio (mesmoNavioQue)");
            System.out.println("      QC3: Identidade sob sortal Matéria (temMesmaMateriaQue)");
            System.out.println("      QC4: Dimensões constitutivas (temCorpo / temMemoria / temConsciencia)");
            System.out.println("      QC5: Identidade psicológica (mesmaPessoaPorMemoria)");
            System.out.println("      QC6: Identidade material (mesmaPessoaPorCorpo)");
            System.out.println("      QC7: Identidade numérica global (owl:sameAs / differentFrom)");

        } catch (Exception e) {
            System.err.println(ANSI_RED + "\n❌ ERRO FATAL: " + e.getMessage() + ANSI_RESET);
            e.printStackTrace();
        }
    }
}