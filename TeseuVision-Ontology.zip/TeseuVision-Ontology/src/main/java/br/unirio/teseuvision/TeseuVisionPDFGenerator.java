package br.unirio.teseuvision;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Text;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * TeseuVisionPDFGenerator - Gerador de PDF para TeseuVision-Ontology
 *
 * Paradoxo do Navio de Teseu e Crise de Identidade do Visão
 * em "WandaVision" (2021)
 *
 * Questões de Competência:
 * Q1: Navios participantes do paradoxo
 * Q2: Navio mesmo NAVIO que o original (mesmoNavioQue)
 * Q3: Navio mesma MATÉRIA que o original (temMesmaMateriaQue)
 * Q4: Dimensões constitutivas de cada Visão
 * Q5: Visão mesma PESSOA por continuidade psicológica
 * Q6: Visão mesma PESSOA por continuidade material
 * Q7: Identidade numérica (owl:sameAs / owl:differentFrom)
 */
public class TeseuVisionPDFGenerator {

    private static final String NS = "http://www.unirio.br/teseuvision/ontology#";

    // ============================================================
    // CAMINHO PADRÃO
    // ============================================================
    private static final String DEFAULT_ONTOLOGY_PATH =
        "D:/EclipseLunar/workspace/TeseuVisionOntology/ontology/teseuvision-ontology.rdf";

    // ============================================================
    // CORES TEMÁTICAS (WandaVision + Navio de Teseu)
    // ============================================================
    private static final Color TV_RED = new DeviceRgb(170, 20, 30);
    private static final Color TV_LIGHT_RED = new DeviceRgb(252, 235, 235);
    private static final Color TV_CRIMSON = new DeviceRgb(200, 30, 60);
    private static final Color TV_DARK_RED = new DeviceRgb(120, 0, 20);
    private static final Color TV_PURPLE = new DeviceRgb(90, 20, 130);
    private static final Color TV_LIGHT_PURPLE = new DeviceRgb(245, 235, 252);
    private static final Color TV_GOLD = new DeviceRgb(200, 160, 20);
    private static final Color TV_TEAL = new DeviceRgb(0, 110, 115);
    private static final Color TV_NAVY = new DeviceRgb(20, 40, 90);
    private static final Color TV_DARK_GRAY = new DeviceRgb(55, 55, 60);
    private static final Color TV_GREEN = new DeviceRgb(0, 130, 60);

    private OWLOntologyManager manager;
    private OWLOntology ontology;
    private OWLDataFactory factory;
    private OWLReasoner reasoner;

    // ============================================================
    // PROPRIEDADES DE OBJETO
    // ============================================================
    private OWLObjectProperty propTemParte;
    private OWLObjectProperty propEParteDe;
    private OWLObjectProperty propEConstituidoPor;
    private OWLObjectProperty propConstitui;
    private OWLObjectProperty propSubstitui;
    private OWLObjectProperty propTemMemoria;
    private OWLObjectProperty propTemConsciencia;
    private OWLObjectProperty propTemCorpo;
    private OWLObjectProperty propMesmoNavioQue;
    private OWLObjectProperty propTemMesmaMateriaQue;
    private OWLObjectProperty propMesmaPessoaPorMemoria;
    private OWLObjectProperty propMesmaPessoaPorCorpo;

    // ============================================================
    // PROPRIEDADES DE DADOS
    // ============================================================
    private OWLDataProperty dphHasName;
    private OWLDataProperty dphHasDescription;
    private OWLDataProperty dphHasYear;
    private OWLDataProperty dphHasCanonicalStatus;
    private OWLDataProperty dphHasCriterioAdotado;
    private OWLDataProperty dphHasFonte;

    // ============================================================
    // CONSTRUTORES
    // ============================================================
    public TeseuVisionPDFGenerator() throws Exception {
        this(loadOntology());
    }

    public TeseuVisionPDFGenerator(OWLOntology ontology) {
        try {
            this.ontology = ontology;
            this.manager = ontology.getOWLOntologyManager();
            this.factory = manager.getOWLDataFactory();

            StructuralReasonerFactory reasonerFactory = new StructuralReasonerFactory();
            this.reasoner = reasonerFactory.createReasoner(ontology);

            initializeProperties();

            System.out.println("✅ Ontologia carregada para PDF");
            System.out.println("   Axiomas: " + ontology.getAxiomCount());
            System.out.println("   Classes: " + ontology.getClassesInSignature().size());
            System.out.println("   Indivíduos: " + ontology.getIndividualsInSignature().size());

        } catch (Exception e) {
            System.err.println("❌ Erro ao carregar ontologia para PDF: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static OWLOntology loadOntology() throws Exception {
        OWLOntologyManager mgr = OWLManager.createOWLOntologyManager();
        File ontologyFile = new File(DEFAULT_ONTOLOGY_PATH);
        if (!ontologyFile.exists()) {
            throw new Exception("Arquivo de ontologia não encontrado: " + ontologyFile.getAbsolutePath());
        }
        System.out.println("📄 Carregando ontologia de: " + ontologyFile.getAbsolutePath());
        return mgr.loadOntologyFromOntologyDocument(ontologyFile);
    }

    private void initializeProperties() {
        propTemParte = getObjectProperty("temParte");
        propEParteDe = getObjectProperty("eParteDe");
        propEConstituidoPor = getObjectProperty("eConstituidoPor");
        propConstitui = getObjectProperty("constitui");
        propSubstitui = getObjectProperty("substitui");
        propTemMemoria = getObjectProperty("temMemoria");
        propTemConsciencia = getObjectProperty("temConsciencia");
        propTemCorpo = getObjectProperty("temCorpo");
        propMesmoNavioQue = getObjectProperty("mesmoNavioQue");
        propTemMesmaMateriaQue = getObjectProperty("temMesmaMateriaQue");
        propMesmaPessoaPorMemoria = getObjectProperty("mesmaPessoaPorMemoria");
        propMesmaPessoaPorCorpo = getObjectProperty("mesmaPessoaPorCorpo");

        dphHasName = getDataProperty("hasName");
        dphHasDescription = getDataProperty("hasDescription");
        dphHasYear = getDataProperty("hasYear");
        dphHasCanonicalStatus = getDataProperty("hasCanonicalStatus");
        dphHasCriterioAdotado = getDataProperty("hasCriterioAdotado");
        dphHasFonte = getDataProperty("hasFonte");
    }

    private OWLObjectProperty getObjectProperty(String name) {
        return factory.getOWLObjectProperty(IRI.create(NS + name));
    }

    private OWLDataProperty getDataProperty(String name) {
        return factory.getOWLDataProperty(IRI.create(NS + name));
    }

    // ============================================================
    // MÉTODOS DE CONSULTA
    // ============================================================

    private Set<OWLNamedIndividual> getIndividualsByPrefix(String prefix) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (ontology == null) return result;

        try {
            Set<OWLNamedIndividual> allInds = ontology.getIndividualsInSignature();
            for (OWLNamedIndividual ind : allInds) {
                String iri = ind.getIRI().getShortForm();
                if (iri.startsWith(prefix)) {
                    result.add(ind);
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    private Set<OWLNamedIndividual> getShips() {
        return getIndividualsByPrefix("Navio");
    }

    private Set<OWLNamedIndividual> getPlanks() {
        return getIndividualsByPrefix("Tabua");
    }

    private Set<OWLNamedIndividual> getAggregates() {
        return getIndividualsByPrefix("Agregado");
    }

    private Set<OWLNamedIndividual> getVisions() {
        return getIndividualsByPrefix("Visao");
    }

    private Set<OWLNamedIndividual> getBodies() {
        return getIndividualsByPrefix("Corpo");
    }

    private Set<OWLNamedIndividual> getMemories() {
        return getIndividualsByPrefix("Memoria");
    }

    private Set<OWLNamedIndividual> getConsciousness() {
        return getIndividualsByPrefix("Consciencia");
    }

    private String getDataValue(OWLNamedIndividual individual, OWLDataProperty prop) {
        if (individual == null || prop == null) return null;
        try {
            Set<OWLDataPropertyAssertionAxiom> axioms = ontology.getDataPropertyAssertionAxioms(individual);
            for (OWLDataPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop)) {
                    OWLLiteral literal = (OWLLiteral) axiom.getObject();
                    return literal.getLiteral();
                }
            }
        } catch (Exception e) { /* ignore */ }
        return null;
    }

    private String getName(OWLNamedIndividual individual) {
        if (individual == null) return "N/A";
        String name = getDataValue(individual, dphHasName);
        if (name != null && !name.isEmpty()) return name;
        String iri = individual.getIRI().getShortForm();
        return iri.replace("_", " ");
    }

    private Set<OWLNamedIndividual> getRelated(OWLNamedIndividual individual, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || prop == null || ontology == null) return result;

        try {
            Set<OWLObjectPropertyAssertionAxiom> axioms = ontology.getObjectPropertyAssertionAxioms(individual);
            for (OWLObjectPropertyAssertionAxiom axiom : axioms) {
                if (axiom.getProperty().equals(prop) && axiom.getSubject().equals(individual)) {
                    OWLIndividual object = axiom.getObject();
                    if (object instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) object);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    private Set<OWLNamedIndividual> getRelatedInverse(OWLNamedIndividual object, OWLObjectProperty prop) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (object == null || prop == null || ontology == null) return result;

        try {
            for (OWLObjectPropertyAssertionAxiom axiom : ontology.getAxioms(AxiomType.OBJECT_PROPERTY_ASSERTION)) {
                if (axiom.getProperty().equals(prop) && axiom.getObject().equals(object)) {
                    OWLIndividual subject = axiom.getSubject();
                    if (subject instanceof OWLNamedIndividual) {
                        result.add((OWLNamedIndividual) subject);
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }

        return result;
    }

    /**
     * Retorna os pares (x, y) tais que x é o mesmo que y via owl:sameAs.
     *
     * CORREÇÃO: OWLSameIndividualAxiom não possui o método contains(...).
     * É preciso iterar sobre getIndividuals() para verificar pertencimento.
     */
    private Set<OWLNamedIndividual> getSameIndividuals(OWLNamedIndividual individual) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || ontology == null) return result;

        try {
            for (OWLSameIndividualAxiom axiom : ontology.getAxioms(AxiomType.SAME_INDIVIDUAL)) {
                Set<OWLIndividual> individuals = axiom.getIndividuals();
                if (individuals.contains(individual)) {
                    for (OWLIndividual ind : individuals) {
                        if (ind instanceof OWLNamedIndividual && !ind.equals(individual)) {
                            result.add((OWLNamedIndividual) ind);
                        }
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    /**
     * Retorna os indivíduos declarados diferentes via owl:differentFrom.
     *
     * CORREÇÃO: OWLDifferentIndividualsAxiom não possui o método contains(...).
     * É preciso iterar sobre getIndividuals() para verificar pertencimento.
     */
    private Set<OWLNamedIndividual> getDifferentIndividuals(OWLNamedIndividual individual) {
        Set<OWLNamedIndividual> result = new HashSet<>();
        if (individual == null || ontology == null) return result;

        try {
            for (OWLDifferentIndividualsAxiom axiom : ontology.getAxioms(AxiomType.DIFFERENT_INDIVIDUALS)) {
                Set<OWLIndividual> individuals = axiom.getIndividuals();
                if (individuals.contains(individual)) {
                    for (OWLIndividual ind : individuals) {
                        if (ind instanceof OWLNamedIndividual && !ind.equals(individual)) {
                            result.add((OWLNamedIndividual) ind);
                        }
                    }
                }
            }
        } catch (Exception e) { /* ignore */ }
        return result;
    }

    // ============================================================
    // GERAR PDF
    // ============================================================
    public void generatePDF(String outputPath) throws IOException {
        if (ontology == null) {
            throw new IOException("Ontologia não foi carregada.");
        }

        File outputFile = new File(outputPath);
        if (outputFile.getParentFile() != null) {
            outputFile.getParentFile().mkdirs();
        }

        PdfWriter writer = new PdfWriter(outputFile);
        PdfDocument pdfDoc = new PdfDocument(writer);
        pdfDoc.setDefaultPageSize(PageSize.A4);

        Document document = new Document(pdfDoc);
        document.setMargins(40, 40, 40, 40);

        PdfFont fontNormal = PdfFontFactory.createFont("Helvetica");
        PdfFont fontBold = PdfFontFactory.createFont("Helvetica-Bold");
        PdfFont fontItalic = PdfFontFactory.createFont("Helvetica-Oblique");

        // ============================================
        // CABEÇALHO
        // ============================================
        Paragraph title = new Paragraph("TeseuVision-Ontology")
                .setFont(fontBold)
                .setFontSize(22)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_RED);
        document.add(title);

        Paragraph subtitle = new Paragraph("Ontologia do Paradoxo do Navio de Teseu e da Identidade do Visão em WandaVision (2021)")
                .setFont(fontBold)
                .setFontSize(12)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY);
        document.add(subtitle);

        Paragraph subtitle2 = new Paragraph("Identidade Diacrônica, Relatividade Sortal e Metafísica Analítica")
                .setFont(fontItalic)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY);
        document.add(subtitle2);

        Paragraph authors = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY);
        authors.add(new Text("Roberto Monteiro Dias,\n").setFont(fontBold));
        authors.add(new Text("Programa de Pós-Graduação em Informática (PPGI)\n"));
        authors.add(new Text("Universidade Federal do Estado do Rio de Janeiro (UNIRIO)\n"));
        authors.add(new Text("Email: roberto.dias@uniriotec.br"));
        document.add(authors);
        document.add(new Paragraph(" ").setFontSize(4));

        Paragraph separator = new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY);
        document.add(separator);

        Paragraph info = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(9)
                .setFontColor(TV_DARK_GRAY);
        info.add(new Text("Data: ").setFont(fontBold));
        info.add(new Text(java.time.LocalDate.now().toString() + "  ").setFont(fontNormal));
        info.add(new Text("Baseado em: ").setFont(fontBold));
        info.add(new Text("Plutarco (c. 100 d.C.) e WandaVision (Marvel, 2021)").setFont(fontItalic));
        document.add(info);
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // RESUMO
        // ============================================
        Paragraph abstractTitle = new Paragraph("Resumo")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(TV_RED);
        document.add(abstractTitle);

        Paragraph abstractText = new Paragraph(
                "Este relatório apresenta a TeseuVision-Ontology, uma ontologia de domínio "
                + "que formaliza o paradoxo do Navio de Teseu e sua aplicação à crise de identidade "
                + "do Visão em WandaVision (2021). A ontologia modela três navios (o original, o "
                + "continuamente reparado e o remontado com peças antigas) e três Visões (o original, "
                + "o Visão do Hex e o Visão Branco), separando identidade numérica global "
                + "(owl:sameAs) de identidades sortais relativas (mesmoNavioQue, temMesmaMateriaQue, "
                + "mesmaPessoaPorMemoria, mesmaPessoaPorCorpo). Essa separação dissolve a contradição "
                + "aparente do paradoxo: cada critério de identidade (material, psicológico ou "
                + "causal-histórico) produz uma resposta diferente, e a ontologia permanece consistente "
                + "porque não usa uma única relação de identidade para todos os contextos."
        ).setFont(fontItalic).setFontSize(9).setTextAlignment(TextAlignment.JUSTIFIED);
        document.add(abstractText);
        document.add(new Paragraph(" ").setFontSize(6));

        // ============================================
        // PALAVRAS-CHAVE
        // ============================================
        Paragraph keywords = new Paragraph()
                .setFont(fontNormal)
                .setFontSize(9)
                .setTextAlignment(TextAlignment.LEFT);
        keywords.add(new Text("Palavras-chave — ").setFont(fontBold));
        keywords.add(new Text("Navio de Teseu, WandaVision, Identidade Diacrônica, Identidade Pessoal, "
                + "Relatividade Sortal, Ontologia, OWL, Visão").setFont(fontItalic));
        document.add(keywords);
        document.add(new Paragraph(" ").setFontSize(8));

        document.add(new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY));
        document.add(new Paragraph(" ").setFontSize(8));

        // ============================================
        // QUESTÕES DE COMPETÊNCIA
        // ============================================
        Paragraph sectionTitle = new Paragraph("I. QUESTÕES DE COMPETÊNCIA")
                .setFont(fontBold)
                .setFontSize(14)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(TV_RED);
        document.add(sectionTitle);
        document.add(new Paragraph(" ").setFontSize(6));

        // Q1 - Navios
        Table q1Table = buildQ1Table(fontNormal, fontBold, fontItalic);
        if (q1Table != null) {
            document.add(q1Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q2 - Mesmo NAVIO
        Table q2Table = buildQ2Table(fontNormal, fontBold, fontItalic);
        if (q2Table != null) {
            document.add(q2Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q3 - Mesma MATÉRIA
        Table q3Table = buildQ3Table(fontNormal, fontBold, fontItalic);
        if (q3Table != null) {
            document.add(q3Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q4 - Dimensões dos Visões
        Table q4Table = buildQ4Table(fontNormal, fontBold, fontItalic);
        if (q4Table != null) {
            document.add(q4Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q5 - Mesma PESSOA por memória
        Table q5Table = buildQ5Table(fontNormal, fontBold, fontItalic);
        if (q5Table != null) {
            document.add(q5Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q6 - Mesma PESSOA por corpo
        Table q6Table = buildQ6Table(fontNormal, fontBold, fontItalic);
        if (q6Table != null) {
            document.add(q6Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // Q7 - Identidade numérica
        Table q7Table = buildQ7Table(fontNormal, fontBold, fontItalic);
        if (q7Table != null) {
            document.add(q7Table);
            document.add(new Paragraph(" ").setFontSize(4));
        }

        // ============================================
        // REFERÊNCIAS
        // ============================================
        document.add(new Paragraph(" ").setFontSize(10));
        document.add(new Paragraph("_________________________________________________________________________________")
                .setFont(fontNormal)
                .setFontSize(10)
                .setTextAlignment(TextAlignment.CENTER)
                .setFontColor(TV_DARK_GRAY));

        Paragraph refTitle = new Paragraph("REFERÊNCIAS")
                .setFont(fontBold)
                .setFontSize(11)
                .setTextAlignment(TextAlignment.LEFT)
                .setFontColor(TV_RED);
        document.add(refTitle);

        Paragraph references = new Paragraph()
                .setTextAlignment(TextAlignment.LEFT)
                .setFontSize(8)
                .setFontColor(TV_DARK_GRAY);

        references.add(new Text("[1] ").setFont(fontBold));
        references.add(new Text("Plutarco, ")
                .setFont(fontNormal));
        references.add(new Text("Vidas Paralelas: Teseu, ")
                .setFont(fontItalic));
        references.add(new Text("c. 100 d.C.\n").setFont(fontNormal));

        references.add(new Text("[2] ").setFont(fontBold));
        references.add(new Text("T. Hobbes, ")
                .setFont(fontNormal));
        references.add(new Text("Leviathan, or The Matter, Forme and Power of a Common Wealth, ")
                .setFont(fontItalic));
        references.add(new Text("Andrew Crooke, 1651.\n").setFont(fontNormal));

        references.add(new Text("[3] ").setFont(fontBold));
        references.add(new Text("J. Locke, ")
                .setFont(fontNormal));
        references.add(new Text("An Essay Concerning Human Understanding, ")
                .setFont(fontItalic));
        references.add(new Text("Thomas Basset, 1690.\n").setFont(fontNormal));

        references.add(new Text("[4] ").setFont(fontBold));
        references.add(new Text("D. Parfit, ")
                .setFont(fontNormal));
        references.add(new Text("Reasons and Persons, ")
                .setFont(fontItalic));
        references.add(new Text("Oxford University Press, 1984.\n").setFont(fontNormal));

        references.add(new Text("[5] ").setFont(fontBold));
        references.add(new Text("D. Wiggins, ")
                .setFont(fontNormal));
        references.add(new Text("Sameness and Substance, ")
                .setFont(fontItalic));
        references.add(new Text("Harvard University Press, 1980.\n").setFont(fontNormal));

        references.add(new Text("[6] ").setFont(fontBold));
        references.add(new Text("P. F. Strawson, ")
                .setFont(fontNormal));
        references.add(new Text("Individuals: An Essay in Descriptive Metaphysics, ")
                .setFont(fontItalic));
        references.add(new Text("Methuen, 1959.\n").setFont(fontNormal));

        references.add(new Text("[7] ").setFont(fontBold));
        references.add(new Text("T. R. Gruber, ")
                .setFont(fontNormal));
        references.add(new Text("\"A Translation Approach to Portable Ontology Specifications,\" ")
                .setFont(fontItalic));
        references.add(new Text("Knowledge Acquisition, vol. 5, no. 2, pp. 199-220, 1993.\n")
                .setFont(fontNormal));

        references.add(new Text("[8] ").setFont(fontBold));
        references.add(new Text("M. Horridge and S. Bechhofer, ")
                .setFont(fontNormal));
        references.add(new Text("\"The OWL API: A Java API for OWL Ontologies,\" ")
                .setFont(fontItalic));
        references.add(new Text("Semantic Web, vol. 2, no. 1, pp. 11-21, 2011.\n")
                .setFont(fontNormal));

        references.add(new Text("[9] ").setFont(fontBold));
        references.add(new Text("J. Schaeffer, ")
                .setFont(fontNormal));
        references.add(new Text("WandaVision, ")
                .setFont(fontItalic));
        references.add(new Text("Marvel Studios / Disney+, 2021.\n").setFont(fontNormal));

        document.add(references);

        // ============================================
        // RODAPÉ
        // ============================================
        document.add(new Paragraph(" ").setFontSize(6));
        Paragraph footer = new Paragraph()
                .setTextAlignment(TextAlignment.CENTER)
                .setFontSize(7)
                .setFontColor(TV_DARK_GRAY);
        footer.add(new Text("© 2026 TeseuVision-Ontology. ").setFont(fontNormal));
        footer.add(new Text("Baseado em Plutarco (c. 100 d.C.) e WandaVision (Marvel, 2021). ").setFont(fontItalic));
        footer.add(new Text("Versão 1.0").setFont(fontNormal));
        document.add(footer);

        document.close();
        pdfDoc.close();

        System.out.println("✅ PDF gerado com sucesso!");
        System.out.println("   📁 " + outputPath);
        System.out.println("   📊 7 Questões de Competência incluídas");
    }

    // ============================================================
    // CONSTRUÇÃO DAS TABELAS
    // ============================================================

    /**
     * QC1 - Quais navios participam do paradoxo?
     */
    private Table buildQ1Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> ships = getShips();
        if (ships.isEmpty()) {
            System.out.println("⚠️ Nenhum navio encontrado na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q1", "QC1",
            "Quais navios participam do paradoxo?",
            TV_NAVY, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);
        int index = 0;

        for (OWLNamedIndividual ship : ships) {
            index++;
            String nome = getName(ship);
            String desc = getDataValue(ship, dphHasDescription);
            String fonte = getDataValue(ship, dphHasFonte);
            String criterio = getDataValue(ship, dphHasCriterioAdotado);
            String ano = getDataValue(ship, dphHasYear);

            Paragraph itemP = new Paragraph();
            itemP.add(new Text(index + ". ").setFont(fontBold).setFontSize(8));
            itemP.add(new Text(nome).setFont(fontBold).setFontSize(8).setFontColor(TV_NAVY));
            if (ano != null && !ano.isEmpty()) {
                itemP.add(new Text(" (" + ano + ")").setFont(fontItalic).setFontSize(7));
            }
            answerCell.add(itemP);

            if (desc != null && !desc.isEmpty()) {
                answerCell.add(new Paragraph("   " + desc)
                    .setFont(fontNormal).setFontSize(7));
            }

            if (criterio != null && !criterio.isEmpty()) {
                Paragraph critP = new Paragraph();
                critP.add(new Text("   Critério adotado: ").setFont(fontItalic).setFontSize(7));
                critP.add(new Text(criterio).setFont(fontBold).setFontSize(7)
                    .setFontColor(TV_PURPLE));
                answerCell.add(critP);
            }

            if (fonte != null && !fonte.isEmpty()) {
                Paragraph srcP = new Paragraph();
                srcP.add(new Text("   Fonte: ").setFont(fontItalic).setFontSize(7));
                srcP.add(new Text(fonte).setFont(fontNormal).setFontSize(7));
                answerCell.add(srcP);
            }

            Set<OWLNamedIndividual> agregados = getRelated(ship, propEConstituidoPor);
            if (!agregados.isEmpty()) {
                Paragraph agP = new Paragraph();
                agP.add(new Text("   Constituído por: ").setFont(fontItalic).setFontSize(7));
                for (OWLNamedIndividual ag : agregados) {
                    agP.add(new Text("[" + getName(ag) + "] ").setFont(fontNormal).setFontSize(7));
                }
                answerCell.add(agP);
            }

            answerCell.add(new Paragraph(" ").setFontSize(1));
        }

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC2 - Qual navio é o mesmo NAVIO que o original? (mesmoNavioQue)
     */
    private Table buildQ2Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        OWLNamedIndividual navioOriginal =
            factory.getOWLNamedIndividual(IRI.create(NS + "NavioOriginal"));

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q2", "QC2",
            "Qual navio é o mesmo NAVIO que o original? (mesmoNavioQue)",
            TV_TEAL, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph intro = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        intro.add(new Text("Critério: ").setFont(fontBold));
        intro.add(new Text("continuidade formal, funcional e causal (relação mesmoNavioQue)."));
        answerCell.add(intro);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        Set<OWLNamedIndividual> mesmos = getRelated(navioOriginal, propMesmoNavioQue);
        mesmos.addAll(getRelatedInverse(navioOriginal, propMesmoNavioQue));

        Paragraph origP = new Paragraph();
        origP.add(new Text("Navio original: ").setFont(fontItalic).setFontSize(7));
        origP.add(new Text(getName(navioOriginal)).setFont(fontBold).setFontSize(8).setFontColor(TV_NAVY));
        answerCell.add(origP);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        if (mesmos.isEmpty()) {
            answerCell.add(new Paragraph("(nenhum par afirmado)")
                .setFont(fontItalic).setFontSize(7));
        } else {
            for (OWLNamedIndividual n : mesmos) {
                Paragraph p = new Paragraph();
                p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
                p.add(new Text(getName(navioOriginal)).setFont(fontBold).setFontSize(7));
                p.add(new Text("  ≡  ").setFont(fontBold).setFontSize(7).setFontColor(TV_TEAL));
                p.add(new Text(getName(n)).setFont(fontBold).setFontSize(7).setFontColor(TV_TEAL));
                answerCell.add(p);
            }
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("Por continuidade formal, funcional e causal, o Navio A "
            + "(peças substituídas continuamente) é o mesmo NAVIO que o original. "
            + "O Navio B, apesar de ter as tábuas originais, NÃO é o mesmo navio sob este critério."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC3 - Qual navio tem a mesma MATÉRIA que o original? (temMesmaMateriaQue)
     */
    private Table buildQ3Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        OWLNamedIndividual navioOriginal =
            factory.getOWLNamedIndividual(IRI.create(NS + "NavioOriginal"));

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q3", "QC3",
            "Qual navio tem a mesma MATÉRIA que o original? (temMesmaMateriaQue)",
            TV_GOLD, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph intro = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        intro.add(new Text("Critério: ").setFont(fontBold));
        intro.add(new Text("compartilhamento do mesmo agregado material (relação temMesmaMateriaQue)."));
        answerCell.add(intro);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        Set<OWLNamedIndividual> mesmaMateria = getRelated(navioOriginal, propTemMesmaMateriaQue);
        mesmaMateria.addAll(getRelatedInverse(navioOriginal, propTemMesmaMateriaQue));

        Paragraph origP = new Paragraph();
        origP.add(new Text("Navio original: ").setFont(fontItalic).setFontSize(7));
        origP.add(new Text(getName(navioOriginal)).setFont(fontBold).setFontSize(8).setFontColor(TV_NAVY));
        answerCell.add(origP);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        if (mesmaMateria.isEmpty()) {
            answerCell.add(new Paragraph("(nenhum par afirmado)")
                .setFont(fontItalic).setFontSize(7));
        } else {
            for (OWLNamedIndividual n : mesmaMateria) {
                Paragraph p = new Paragraph();
                p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
                p.add(new Text(getName(navioOriginal)).setFont(fontBold).setFontSize(7));
                p.add(new Text("  ≡  ").setFont(fontBold).setFontSize(7).setFontColor(TV_GOLD));
                p.add(new Text(getName(n)).setFont(fontBold).setFontSize(7).setFontColor(TV_GOLD));
                answerCell.add(p);

                Set<OWLNamedIndividual> agOrig = getRelated(navioOriginal, propEConstituidoPor);
                Set<OWLNamedIndividual> agOutro = getRelated(n, propEConstituidoPor);
                Set<OWLNamedIndividual> intersec = new HashSet<>(agOrig);
                intersec.retainAll(agOutro);
                if (!intersec.isEmpty()) {
                    Paragraph agP = new Paragraph();
                    agP.add(new Text("       Agregado compartilhado: ").setFont(fontItalic).setFontSize(7));
                    for (OWLNamedIndividual ag : intersec) {
                        agP.add(new Text("[" + getName(ag) + "] ").setFont(fontNormal).setFontSize(7));
                    }
                    answerCell.add(agP);
                }
            }
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("Por compartilhar o mesmo agregado material (as tábuas originais), "
            + "o Navio B tem a mesma MATÉRIA que o original. O Navio A NÃO tem a mesma matéria, "
            + "embora seja o mesmo navio."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC4 - Quais são as dimensões constitutivas de cada Visão?
     */
    private Table buildQ4Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> visoes = getVisions();
        if (visoes.isEmpty()) {
            System.out.println("⚠️ Nenhum Visão encontrado na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q4", "QC4",
            "Quais são as dimensões constitutivas de cada Visão?",
            TV_PURPLE, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        int index = 0;
        for (OWLNamedIndividual visao : visoes) {
            index++;
            String nome = getName(visao);
            String desc = getDataValue(visao, dphHasDescription);
            String criterio = getDataValue(visao, dphHasCriterioAdotado);

            Paragraph vP = new Paragraph();
            vP.add(new Text(index + ". ").setFont(fontBold).setFontSize(9));
            vP.add(new Text(nome).setFont(fontBold).setFontSize(9).setFontColor(TV_RED));
            answerCell.add(vP);

            if (desc != null && !desc.isEmpty()) {
                answerCell.add(new Paragraph("   " + desc)
                    .setFont(fontNormal).setFontSize(7));
            }

            if (criterio != null && !criterio.isEmpty()) {
                Paragraph cP = new Paragraph();
                cP.add(new Text("   Critério adotado: ").setFont(fontItalic).setFontSize(7));
                cP.add(new Text(criterio).setFont(fontBold).setFontSize(7).setFontColor(TV_PURPLE));
                answerCell.add(cP);
            }

            // Corpo
            Set<OWLNamedIndividual> corpos = getRelated(visao, propTemCorpo);
            Paragraph corpoP = new Paragraph();
            corpoP.add(new Text("   Corpo: ").setFont(fontItalic).setFontSize(7));
            if (corpos.isEmpty()) {
                corpoP.add(new Text("(ausente)").setFont(fontNormal).setFontSize(7).setFontColor(TV_CRIMSON));
            } else {
                for (OWLNamedIndividual c : corpos) {
                    corpoP.add(new Text("[" + getName(c) + "] ").setFont(fontBold).setFontSize(7).setFontColor(TV_NAVY));
                }
            }
            answerCell.add(corpoP);

            // Memória
            Set<OWLNamedIndividual> memorias = getRelated(visao, propTemMemoria);
            Paragraph memP = new Paragraph();
            memP.add(new Text("   Memória: ").setFont(fontItalic).setFontSize(7));
            if (memorias.isEmpty()) {
                memP.add(new Text("(ausente)").setFont(fontNormal).setFontSize(7).setFontColor(TV_CRIMSON));
            } else {
                for (OWLNamedIndividual m : memorias) {
                    memP.add(new Text("[" + getName(m) + "] ").setFont(fontBold).setFontSize(7).setFontColor(TV_TEAL));
                }
            }
            answerCell.add(memP);

            // Consciência
            Set<OWLNamedIndividual> consciencias = getRelated(visao, propTemConsciencia);
            Paragraph consP = new Paragraph();
            consP.add(new Text("   Consciência: ").setFont(fontItalic).setFontSize(7));
            if (consciencias.isEmpty()) {
                consP.add(new Text("(ausente)").setFont(fontNormal).setFontSize(7).setFontColor(TV_CRIMSON));
            } else {
                for (OWLNamedIndividual c : consciencias) {
                    consP.add(new Text("[" + getName(c) + "] ").setFont(fontBold).setFontSize(7).setFontColor(TV_GOLD));
                }
            }
            answerCell.add(consP);

            answerCell.add(new Paragraph(" ").setFontSize(2));
        }

        answerCell.add(new Paragraph(" ").setFontSize(2));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Resumo: ").setFont(fontBold));
        interp.add(new Text("Visão original tem corpo, memória e consciência originais; "
            + "o Visão do Hex tem memória original e consciência própria, mas SEM corpo; "
            + "o Visão Branco tem corpo original e consciência própria, mas SEM memórias."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC5 - Qual Visão é a mesma PESSOA por continuidade psicológica?
     */
    private Table buildQ5Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        OWLNamedIndividual visaoOriginal =
            factory.getOWLNamedIndividual(IRI.create(NS + "VisaoOriginal"));

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q5", "QC5",
            "Qual Visão é a mesma PESSOA por continuidade psicológica? (mesmaPessoaPorMemoria)",
            TV_TEAL, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph intro = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        intro.add(new Text("Critério de Locke: ").setFont(fontBold));
        intro.add(new Text("uma pessoa é a mesma enquanto mantiver memórias, caráter e consciência."));
        answerCell.add(intro);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        Set<OWLNamedIndividual> mesmos = getRelated(visaoOriginal, propMesmaPessoaPorMemoria);
        mesmos.addAll(getRelatedInverse(visaoOriginal, propMesmaPessoaPorMemoria));

        Paragraph origP = new Paragraph();
        origP.add(new Text("Visão original: ").setFont(fontItalic).setFontSize(7));
        origP.add(new Text(getName(visaoOriginal)).setFont(fontBold).setFontSize(8).setFontColor(TV_RED));
        answerCell.add(origP);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        if (mesmos.isEmpty()) {
            answerCell.add(new Paragraph("(nenhum par afirmado)")
                .setFont(fontItalic).setFontSize(7));
        } else {
            for (OWLNamedIndividual v : mesmos) {
                Paragraph p = new Paragraph();
                p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
                p.add(new Text(getName(visaoOriginal)).setFont(fontBold).setFontSize(7));
                p.add(new Text("  ≡  ").setFont(fontBold).setFontSize(7).setFontColor(TV_TEAL));
                p.add(new Text(getName(v)).setFont(fontBold).setFontSize(7).setFontColor(TV_TEAL));
                answerCell.add(p);

                Set<OWLNamedIndividual> memOrig = getRelated(visaoOriginal, propTemMemoria);
                Set<OWLNamedIndividual> memOutro = getRelated(v, propTemMemoria);
                Set<OWLNamedIndividual> intersec = new HashSet<>(memOrig);
                intersec.retainAll(memOutro);
                if (!intersec.isEmpty()) {
                    Paragraph mP = new Paragraph();
                    mP.add(new Text("       Memória compartilhada: ").setFont(fontItalic).setFontSize(7));
                    for (OWLNamedIndividual m : intersec) {
                        mP.add(new Text("[" + getName(m) + "] ").setFont(fontNormal).setFontSize(7));
                    }
                    answerCell.add(mP);
                }
            }
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("O Visão do Hex compartilha as memórias e a personalidade do Visão "
            + "original. Sob o critério da continuidade psicológica (Locke), ele é a mesma PESSOA."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC6 - Qual Visão é a mesma PESSOA por continuidade material?
     */
    private Table buildQ6Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        OWLNamedIndividual visaoOriginal =
            factory.getOWLNamedIndividual(IRI.create(NS + "VisaoOriginal"));

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q6", "QC6",
            "Qual Visão é a mesma PESSOA por continuidade material? (mesmaPessoaPorCorpo)",
            TV_GOLD, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph intro = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        intro.add(new Text("Critério materialista: ").setFont(fontBold));
        intro.add(new Text("uma pessoa é a mesma enquanto mantiver o mesmo corpo físico."));
        answerCell.add(intro);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        Set<OWLNamedIndividual> mesmos = getRelated(visaoOriginal, propMesmaPessoaPorCorpo);
        mesmos.addAll(getRelatedInverse(visaoOriginal, propMesmaPessoaPorCorpo));

        Paragraph origP = new Paragraph();
        origP.add(new Text("Visão original: ").setFont(fontItalic).setFontSize(7));
        origP.add(new Text(getName(visaoOriginal)).setFont(fontBold).setFontSize(8).setFontColor(TV_RED));
        answerCell.add(origP);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        if (mesmos.isEmpty()) {
            answerCell.add(new Paragraph("(nenhum par afirmado)")
                .setFont(fontItalic).setFontSize(7));
        } else {
            for (OWLNamedIndividual v : mesmos) {
                Paragraph p = new Paragraph();
                p.add(new Text("   • ").setFont(fontNormal).setFontSize(7));
                p.add(new Text(getName(visaoOriginal)).setFont(fontBold).setFontSize(7));
                p.add(new Text("  ≡  ").setFont(fontBold).setFontSize(7).setFontColor(TV_GOLD));
                p.add(new Text(getName(v)).setFont(fontBold).setFontSize(7).setFontColor(TV_GOLD));
                answerCell.add(p);

                Set<OWLNamedIndividual> corpoOrig = getRelated(visaoOriginal, propTemCorpo);
                Set<OWLNamedIndividual> corpoOutro = getRelated(v, propTemCorpo);
                Set<OWLNamedIndividual> intersec = new HashSet<>(corpoOrig);
                intersec.retainAll(corpoOutro);
                if (!intersec.isEmpty()) {
                    Paragraph cP = new Paragraph();
                    cP.add(new Text("       Corpo compartilhado: ").setFont(fontItalic).setFontSize(7));
                    for (OWLNamedIndividual c : intersec) {
                        cP.add(new Text("[" + getName(c) + "] ").setFont(fontNormal).setFontSize(7));
                    }
                    answerCell.add(cP);
                }
            }
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("O Visão Branco possui o corpo físico original do Visão. "
            + "Sob o critério da continuidade material, ele é a mesma PESSOA."));
        answerCell.add(interp);

        table.addCell(answerCell);
        return table;
    }

    /**
     * QC7 - Algum Visão é numericamente idêntico (owl:sameAs) ao original?
     */
    private Table buildQ7Table(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Set<OWLNamedIndividual> visoes = getVisions();
        if (visoes.isEmpty()) {
            System.out.println("⚠️ Nenhum Visão encontrado na ontologia.");
            return null;
        }

        Table table = new Table(UnitValue.createPercentArray(new float[]{50, 50}));
        table.setWidth(UnitValue.createPercentValue(100));

        Cell questionCell = createQuestionCell("Q7", "QC7",
            "Algum Visão é numericamente idêntico (owl:sameAs) ao original?",
            TV_CRIMSON, fontNormal, fontBold, fontItalic);
        table.addCell(questionCell);

        Cell answerCell = createAnswerCell(fontNormal, fontBold, fontItalic);

        Paragraph intro = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        intro.add(new Text("Identidade numérica global: ").setFont(fontBold));
        intro.add(new Text("relação owl:sameAs vs. owl:differentFrom."));
        answerCell.add(intro);
        answerCell.add(new Paragraph(" ").setFontSize(2));

        for (OWLNamedIndividual visao : visoes) {
            String nome = getName(visao);

            Paragraph vP = new Paragraph();
            vP.add(new Text("👤 ").setFontSize(8));
            vP.add(new Text(nome).setFont(fontBold).setFontSize(8).setFontColor(TV_RED));
            answerCell.add(vP);

            // owl:sameAs
            Set<OWLNamedIndividual> same = getSameIndividuals(visao);
            Paragraph sameP = new Paragraph();
            sameP.add(new Text("     owl:sameAs: ").setFont(fontItalic).setFontSize(7));
            if (same.isEmpty()) {
                sameP.add(new Text("(nenhum)").setFont(fontNormal).setFontSize(7).setFontColor(TV_DARK_GRAY));
            } else {
                for (OWLNamedIndividual s : same) {
                    sameP.add(new Text("[" + getName(s) + "] ")
                        .setFont(fontBold).setFontSize(7).setFontColor(TV_GREEN));
                }
            }
            answerCell.add(sameP);

            // owl:differentFrom
            Set<OWLNamedIndividual> diff = getDifferentIndividuals(visao);
            Paragraph diffP = new Paragraph();
            diffP.add(new Text("     owl:differentFrom: ").setFont(fontItalic).setFontSize(7));
            if (diff.isEmpty()) {
                diffP.add(new Text("(nenhum)").setFont(fontNormal).setFontSize(7).setFontColor(TV_DARK_GRAY));
            } else {
                for (OWLNamedIndividual d : diff) {
                    diffP.add(new Text("[" + getName(d) + "] ")
                        .setFont(fontBold).setFontSize(7).setFontColor(TV_CRIMSON));
                }
            }
            answerCell.add(diffP);

            answerCell.add(new Paragraph(" ").setFontSize(2));
        }

        answerCell.add(new Paragraph(" ").setFontSize(3));
        Paragraph interp = new Paragraph()
            .setFont(fontItalic).setFontSize(7).setFontColor(TV_DARK_GRAY);
        interp.add(new Text("Interpretação: ").setFont(fontBold));
        interp.add(new Text("Nenhum Visão é numericamente idêntico ao original. As identidades "
            + "afirmadas são SORTAIS (por memória, por corpo), não numéricas. Isso é exatamente "
            + "o que dissolve o paradoxo: cada critério produz uma resposta diferente, e a "
            + "ontologia permanece consistente porque separa os critérios."));

        answerCell.add(new Paragraph(" ").setFontSize(2));
        Paragraph conclusao = new Paragraph()
            .setFont(fontBold).setFontSize(7).setFontColor(TV_CRIMSON);
        conclusao.add(new Text("VisaoHex    owl:sameAs VisaoOriginal = false\n"));
        conclusao.add(new Text("VisaoBranco owl:sameAs VisaoOriginal = false\n"));
        conclusao.add(new Text("VisaoHex    owl:sameAs VisaoBranco   = false\n"));
        conclusao.add(new Text("VisaoHex    owl:differentFrom VisaoBranco = true"));
        answerCell.add(conclusao);

        table.addCell(answerCell);
        return table;
    }

    // ============================================================
    // MÉTODOS AUXILIARES
    // ============================================================

    private Cell createQuestionCell(String qId, String rq, String question, Color color,
                                   PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Cell questionCell = new Cell();
        questionCell.setBackgroundColor(color);
        questionCell.setPadding(12);
        questionCell.setBorder(null);

        Paragraph qIdP = new Paragraph(qId)
                .setFont(fontBold)
                .setFontSize(16)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
        questionCell.add(qIdP);

        Paragraph rqP = new Paragraph("Questão: " + rq)
                .setFont(fontItalic)
                .setFontSize(8)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.CENTER);
        questionCell.add(rqP);

        Paragraph qcQuestion = new Paragraph(question)
                .setFont(fontNormal)
                .setFontSize(8)
                .setFontColor(DeviceRgb.WHITE)
                .setTextAlignment(TextAlignment.LEFT)
                .setMarginTop(6);
        questionCell.add(qcQuestion);

        return questionCell;
    }

    private Cell createAnswerCell(PdfFont fontNormal, PdfFont fontBold, PdfFont fontItalic) {
        Cell answerCell = new Cell();
        answerCell.setPadding(12);
        answerCell.setBorder(null);
        answerCell.setBackgroundColor(TV_LIGHT_RED);

        Paragraph answerTitle = new Paragraph("RESPOSTA")
                .setFont(fontBold)
                .setFontSize(9)
                .setFontColor(TV_DARK_GRAY);
        answerCell.add(answerTitle);

        return answerCell;
    }

    // ============================================================
    // MAIN
    // ============================================================
    public static void main(String[] args) {
        try {
            TeseuVisionPDFGenerator generator = new TeseuVisionPDFGenerator();
            String outputPath =
                "D:/EclipseLunar/workspace/TeseuVisionOntology/ontology/teseuvision-ieee-2026.pdf";
            generator.generatePDF(outputPath);
            System.out.println("\n✅ PDF gerado com sucesso em: " + outputPath);
        } catch (Exception e) {
            System.err.println("❌ Erro: " + e.getMessage());
            e.printStackTrace();
        }
    }
}